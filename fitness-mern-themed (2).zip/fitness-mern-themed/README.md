# FitZone — MERN Fitness Tracker

MongoDB · Express · React (Vite) · Node.js. Members track workouts, nutrition and progress; administrators manage the whole platform from a modern, responsive admin console.

## Admin console (rebuilt)
Open `/admin/dashboard` after logging in with an admin account.

| Area | What it does |
| --- | --- |
| **Dashboard** | KPI cards, 14-day activity chart, member-growth chart, records-by-category donut, nutrition macro snapshot, most-active members, newest members, recent activity and an admin audit log |
| **Users** | Server-side search, role/status filters, sortable columns, pagination, create / edit / reset password, suspend / reactivate, delete, member detail view, CSV export |
| **Exercises, Workouts, Weight, Measurements, Performance, Nutrition, Goals** | One data-driven page per tracker: search, member filter, date range, add / edit / delete on behalf of a member, shared library for exercises and workouts, CSV export |
| **Notifications** | Broadcast announcements, reminders and alerts to everyone, clients only, or one member; read-rate per broadcast; delete a broadcast |
| **Support** | Ticket inbox with status tabs, priority, search, threaded replies (members are notified in-app), resolve and delete |
| **Reports & export** | CSV and print-ready PDF reports for users, every tracker and support tickets, with an optional date range |
| **Settings** | Profile photo and details, light/dark theme, units, notification preferences, change password |

Members get a matching **Support** page at `/client/support` to open tickets and send feedback.

Other improvements: confirm dialogs and toasts instead of `prompt()`/`confirm()`, light and dark themes, mobile off-canvas sidebar, keyboard-accessible controls and ARIA labels, CSV export protected against spreadsheet formula injection, suspended accounts are blocked on every request (not only at login), admins cannot demote, suspend or delete themselves, and the last admin cannot delete their own account.

## Run locally
1. In `backend`, copy `.env.example` to `.env` and set `MONGODB_URI`, `JWT_SECRET` (long and random), `CLIENT_URL`, `PORT`, plus `ADMIN_EMAIL` / `ADMIN_PASSWORD` (12+ characters).
2. `cd backend && npm install && npm run seed:admin && npm run dev`
3. `cd frontend && npm install && npm run dev`
4. Open the Vite URL (usually http://localhost:5173) and log in with the admin credentials from step 1.

Never commit or share `.env`. If database credentials were ever shared (for example inside a zip), rotate them in MongoDB Atlas.

## Admin API (all require an admin JWT)
- `GET /api/admin/analytics`, `GET /api/admin/badges`, `GET /api/admin/audit`
- `GET|POST /api/admin/users`, `GET|PATCH|DELETE /api/admin/users/:id`
- `GET|POST /api/admin/notifications`, `DELETE /api/admin/notifications/:id`
- `GET /api/admin/tickets`, `PATCH|DELETE /api/admin/tickets/:id`
- `GET /api/admin/export/:what?from&to&format=csv|json` (`users`, `tickets`, `exercise`, `workout`, `weight`, `measurement`, `performance`, `food`, `goal`)
- `GET /api/fitness/:type?all=true&q&owner&from&to&limit`, plus the existing create / update / delete routes

Member support API: `GET /api/support/mine`, `POST /api/support`, `POST /api/support/:id/reply`.

## Project structure
- `backend/routes/adminRoutes.js` — analytics, users, notifications, tickets, exports
- `backend/routes/fitnessRoutes.js` — own-profile and tracker CRUD with filters
- `backend/routes/supportRoutes.js` — member tickets
- `backend/models/` — `User`, `FitnessRecord`, `Ticket`, `AuditLog`
- `frontend/src/admin/` — admin layout, pages, charts, UI kit and styles (`admin.css`)
