const bcrypt = require("bcryptjs");
const User = require("../models/User");
const createToken = require("../utils/createToken");

function safeUser(user) { return { id:user._id,name:user.name,email:user.email,role:user.role,phone:user.phone||"",age:user.age??"",heightCm:user.heightCm??"",currentWeight:user.currentWeight??"",fitnessGoal:user.fitnessGoal||"",profileImage:user.profileImage||"",status:user.status||"active",createdAt:user.createdAt,lastLoginAt:user.lastLoginAt||null,preferences:{theme:user.preferences?.theme||"dark",units:user.preferences?.units||"metric",emailNotifications:user.preferences?.emailNotifications??true,workoutReminders:user.preferences?.workoutReminders??true} }; }

exports.safeUser = safeUser;
exports.register = async (req, res, next) => {
  try {
    const name = String(req.body.name || "").trim();
    const email = String(req.body.email || "").trim().toLowerCase();
    const password = String(req.body.password || "");
    if (name.length < 2) return res.status(400).json({ message: "Name must contain at least 2 characters." });
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return res.status(400).json({ message: "Enter a valid email address." });
    if (password.length < 8) return res.status(400).json({ message: "Password must be at least 8 characters." });

    const exists = await User.findOne({ email });
    if (exists) return res.status(409).json({ message: "An account with this email already exists." });

    const hash = await bcrypt.hash(password, 12);
    // Public registration can only create client accounts.
    const user = await User.create({ name, email, password: hash, role: "client" });
    return res.status(201).json({ message: "Account created.", token: createToken(user), user: safeUser(user) });
  } catch (error) {
    if (error.code === 11000) return res.status(409).json({ message: "Email is already registered." });
    next(error);
  }
};

exports.login = async (req, res, next) => {
  try {
    const email = String(req.body.email || "").trim().toLowerCase();
    const password = String(req.body.password || "");
    if (!email || !password) return res.status(400).json({ message: "Email and password are required." });

    const user = await User.findOne({ email }).select("+password");
    if (!user || !(await bcrypt.compare(password, user.password))) {
      return res.status(401).json({ message: "Incorrect email or password." });
    }
    if (user.status === "suspended") return res.status(403).json({ message: "This account is suspended. Contact the administrator." });
    user.lastLoginAt = new Date();
    await User.updateOne({ _id: user._id }, { $set: { lastLoginAt: user.lastLoginAt } });
    return res.json({ message: "Login successful.", token: createToken(user), user: safeUser(user) });
  } catch (error) {
    next(error);
  }
};

exports.me = async (req, res) => res.json({ user: safeUser(req.user) });
