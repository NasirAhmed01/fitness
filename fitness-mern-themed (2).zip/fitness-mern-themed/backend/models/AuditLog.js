const mongoose = require("mongoose");

const auditSchema = new mongoose.Schema(
  {
    actor: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
    actorName: { type: String, default: "" },
    action: { type: String, required: true },
    target: { type: String, default: "" }
  },
  { timestamps: true }
);
auditSchema.index({ createdAt: -1 });

module.exports = mongoose.model("AuditLog", auditSchema);
