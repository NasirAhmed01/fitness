const mongoose = require("mongoose");

const schema = new mongoose.Schema(
  {
    owner: { type: mongoose.Schema.Types.ObjectId, ref: "User", index: true },
    type: {
      type: String,
      enum: ["exercise", "workout", "weight", "measurement", "performance", "food", "goal", "notification"],
      required: true,
      index: true
    },
    title: { type: String, required: true, trim: true, maxlength: 120 },
    date: { type: Date, default: Date.now },
    details: { type: mongoose.Schema.Types.Mixed, default: {} },
    read: { type: Boolean, default: false },
    // Groups the per-user copies of one admin broadcast so it can be managed as a single item.
    batch: { type: String, index: true, default: undefined }
  },
  { timestamps: true }
);
schema.index({ owner: 1, type: 1, date: -1 });

module.exports = mongoose.model("FitnessRecord", schema);
