const mongoose = require("mongoose");

const preferencesSchema = new mongoose.Schema(
  {
    theme: { type: String, enum: ["dark", "light"], default: "dark" },
    units: { type: String, enum: ["metric", "imperial"], default: "metric" },
    emailNotifications: { type: Boolean, default: true },
    workoutReminders: { type: Boolean, default: true }
  },
  { _id: false }
);

const userSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true, maxlength: 80 },
    email: { type: String, required: true, unique: true, lowercase: true, trim: true },
    password: { type: String, required: true, minlength: 8, select: false },
    role: { type: String, enum: ["admin", "client"], default: "client" },
    phone: { type: String, trim: true, maxlength: 30, default: "" },
    age: { type: Number, min: 13, max: 120, default: null },
    heightCm: { type: Number, min: 50, max: 260, default: null },
    currentWeight: { type: Number, min: 20, max: 500, default: null },
    fitnessGoal: { type: String, enum: ["muscle_gain", "weight_loss", "maintenance", "general_fitness", ""], default: "" },
    profileImage: { type: String, default: "" },
    status: { type: String, enum: ["active", "suspended"], default: "active" },
    lastLoginAt: { type: Date, default: null },
    preferences: { type: preferencesSchema, default: () => ({}) }
  },
  { timestamps: true }
);

module.exports = mongoose.model("User", userSchema);
