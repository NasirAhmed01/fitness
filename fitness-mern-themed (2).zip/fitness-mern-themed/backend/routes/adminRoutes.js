const express = require("express");
const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");
const crypto = require("crypto");
const User = require("../models/User");
const FitnessRecord = require("../models/FitnessRecord");
const Ticket = require("../models/Ticket");
const AuditLog = require("../models/AuditLog");
const { protect, allowRoles } = require("../middleware/auth");
const { safeUser } = require("../controllers/authController");
const audit = require("../utils/audit");
const { toCsv } = require("../utils/csv");

const router = express.Router();
const TRACKERS = ["exercise", "workout", "weight", "measurement", "performance", "food", "goal"];
const EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const escapeRegex = (text) => String(text).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
const num = (field) => ({ $convert: { input: field, to: "double", onError: null, onNull: null } });

router.use("/admin", protect, allowRoles("admin"));

/* ------------------------------ Dashboard ------------------------------ */
router.get("/admin/analytics", async (_req, res, next) => {
  try {
    const now = new Date();
    const monthStart = new Date(now.getFullYear(), now.getMonth() - 5, 1);
    const dayStart = new Date(now); dayStart.setDate(now.getDate() - 13); dayStart.setHours(0, 0, 0, 0);
    const weekAgo = new Date(now.getTime() - 7 * 864e5);
    const notNotification = { type: { $ne: "notification" } };

    const [roles, statuses, signupsRaw, typeCounts, activityRaw, topRaw, macroRaw, openTickets, newThisWeek, recentUsers, recentRecords, logs] = await Promise.all([
      User.aggregate([{ $group: { _id: "$role", count: { $sum: 1 } } }]),
      User.aggregate([{ $group: { _id: "$status", count: { $sum: 1 } } }]),
      User.aggregate([{ $match: { createdAt: { $gte: monthStart } } }, { $group: { _id: { y: { $year: "$createdAt" }, m: { $month: "$createdAt" } }, count: { $sum: 1 } } }]),
      FitnessRecord.aggregate([{ $match: notNotification }, { $group: { _id: "$type", count: { $sum: 1 } } }]),
      FitnessRecord.aggregate([{ $match: { ...notNotification, createdAt: { $gte: dayStart } } }, { $group: { _id: { $dateToString: { format: "%Y-%m-%d", date: "$createdAt" } }, count: { $sum: 1 } } }]),
      FitnessRecord.aggregate([
        { $match: notNotification }, { $group: { _id: "$owner", count: { $sum: 1 } } }, { $sort: { count: -1 } }, { $limit: 5 },
        { $lookup: { from: "users", localField: "_id", foreignField: "_id", as: "user" } }, { $unwind: "$user" },
        { $project: { count: 1, name: "$user.name", email: "$user.email", profileImage: "$user.profileImage" } }
      ]),
      FitnessRecord.aggregate([
        { $match: { type: "food", createdAt: { $gte: dayStart } } },
        { $group: { _id: null, entries: { $sum: 1 }, calories: { $avg: num("$details.calories") }, protein: { $sum: num("$details.protein") }, carbs: { $sum: num("$details.carbs") }, fats: { $sum: num("$details.fats") } } }
      ]),
      Ticket.countDocuments({ status: { $in: ["open", "in_progress"] } }),
      User.countDocuments({ createdAt: { $gte: weekAgo } }),
      User.find().sort({ createdAt: -1 }).limit(6),
      FitnessRecord.find(notNotification).sort({ createdAt: -1 }).limit(8).populate("owner", "name"),
      AuditLog.find().sort({ createdAt: -1 }).limit(8)
    ]);

    const roleMap = Object.fromEntries(roles.map((r) => [r._id, r.count]));
    const statusMap = Object.fromEntries(statuses.map((r) => [r._id || "active", r.count]));

    const signups = [];
    for (let i = 5; i >= 0; i--) {
      const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
      const hit = signupsRaw.find((r) => r._id.y === d.getFullYear() && r._id.m === d.getMonth() + 1);
      signups.push({ label: d.toLocaleString("en-US", { month: "short" }), value: hit ? hit.count : 0 });
    }
    const activity = [];
    for (let i = 13; i >= 0; i--) {
      const d = new Date(dayStart); d.setDate(dayStart.getDate() + (13 - i));
      const key = d.toISOString().slice(0, 10);
      const hit = activityRaw.find((r) => r._id === key);
      activity.push({ label: d.toLocaleString("en-US", { month: "short", day: "numeric" }), value: hit ? hit.count : 0 });
    }
    const macro = macroRaw[0] || {};
    const byType = TRACKERS.map((t) => ({ type: t, count: typeCounts.find((r) => r._id === t)?.count || 0 }));

    res.json({
      kpis: {
        totalUsers: (roleMap.client || 0) + (roleMap.admin || 0), clients: roleMap.client || 0, admins: roleMap.admin || 0,
        suspended: statusMap.suspended || 0, newThisWeek, openTickets, totalRecords: byType.reduce((s, r) => s + r.count, 0)
      },
      signups, activity, byType,
      topUsers: topRaw.map((u) => ({ id: u._id, name: u.name, email: u.email, profileImage: u.profileImage, count: u.count })),
      macros: { entries: macro.entries || 0, avgCalories: Math.round(macro.calories || 0), protein: Math.round(macro.protein || 0), carbs: Math.round(macro.carbs || 0), fats: Math.round(macro.fats || 0) },
      recentUsers: recentUsers.map(safeUser),
      recentRecords: recentRecords.map((r) => ({ id: r._id, type: r.type, title: r.title, owner: r.owner?.name || "Shared library", createdAt: r.createdAt })),
      logs: logs.map((l) => ({ id: l._id, actorName: l.actorName, action: l.action, target: l.target, createdAt: l.createdAt }))
    });
  } catch (e) { next(e); }
});

router.get("/admin/badges", async (_req, res, next) => {
  try { res.json({ openTickets: await Ticket.countDocuments({ status: "open" }) }); } catch (e) { next(e); }
});

router.get("/admin/audit", async (req, res, next) => {
  try {
    const limit = Math.min(parseInt(req.query.limit, 10) || 50, 200);
    res.json({ logs: await AuditLog.find().sort({ createdAt: -1 }).limit(limit) });
  } catch (e) { next(e); }
});

/* -------------------------------- Users -------------------------------- */
function userFilter(query) {
  const filter = {};
  if (query.q) {
    const rx = { $regex: escapeRegex(String(query.q).slice(0, 80)), $options: "i" };
    filter.$or = [{ name: rx }, { email: rx }, { phone: rx }];
  }
  if (["admin", "client"].includes(query.role)) filter.role = query.role;
  if (["active", "suspended"].includes(query.status)) filter.status = query.status;
  return filter;
}

router.get("/admin/users", async (req, res, next) => {
  try {
    const limit = Math.min(Math.max(parseInt(req.query.limit, 10) || 10, 1), 500);
    const page = Math.max(parseInt(req.query.page, 10) || 1, 1);
    const filter = userFilter(req.query);
    const sortKey = ["name", "email", "createdAt", "lastLoginAt"].includes(req.query.sort) ? req.query.sort : "createdAt";
    const sortDir = req.query.dir === "asc" ? 1 : -1;
    const [total, users] = await Promise.all([
      User.countDocuments(filter),
      User.find(filter).sort({ [sortKey]: sortDir }).skip((page - 1) * limit).limit(limit)
    ]);
    const counts = await FitnessRecord.aggregate([
      { $match: { owner: { $in: users.map((u) => u._id) }, type: { $ne: "notification" } } },
      { $group: { _id: "$owner", count: { $sum: 1 } } }
    ]);
    const countMap = Object.fromEntries(counts.map((c) => [String(c._id), c.count]));
    res.json({ users: users.map((u) => ({ ...safeUser(u), records: countMap[String(u._id)] || 0 })), total, page, pages: Math.max(Math.ceil(total / limit), 1) });
  } catch (e) { next(e); }
});

router.get("/admin/users/:id", async (req, res, next) => {
  try {
    if (!mongoose.isValidObjectId(req.params.id)) return res.status(404).json({ message: "User not found." });
    const user = await User.findById(req.params.id);
    if (!user) return res.status(404).json({ message: "User not found." });
    const [counts, recent, tickets] = await Promise.all([
      FitnessRecord.aggregate([{ $match: { owner: user._id } }, { $group: { _id: "$type", count: { $sum: 1 } } }]),
      FitnessRecord.find({ owner: user._id, type: { $ne: "notification" } }).sort({ createdAt: -1 }).limit(6),
      Ticket.countDocuments({ owner: user._id })
    ]);
    res.json({
      user: safeUser(user), tickets,
      counts: Object.fromEntries(counts.map((c) => [c._id, c.count])),
      recent: recent.map((r) => ({ id: r._id, type: r.type, title: r.title, date: r.date }))
    });
  } catch (e) { next(e); }
});

router.post("/admin/users", async (req, res, next) => {
  try {
    const name = String(req.body.name || "").trim();
    const email = String(req.body.email || "").trim().toLowerCase();
    const password = String(req.body.password || "");
    if (name.length < 2) return res.status(400).json({ message: "Name must contain at least 2 characters." });
    if (!EMAIL.test(email)) return res.status(400).json({ message: "Enter a valid email address." });
    if (password.length < 8) return res.status(400).json({ message: "Password must be at least 8 characters." });
    const extra = {};
    for (const k of ["phone", "age", "heightCm", "currentWeight", "fitnessGoal"]) if (req.body[k] !== undefined && req.body[k] !== "") extra[k] = req.body[k];
    const user = await User.create({ ...extra, name, email, password: await bcrypt.hash(password, 12), role: req.body.role === "admin" ? "admin" : "client", status: req.body.status === "suspended" ? "suspended" : "active" });
    await audit(req, "Created user", `${user.name} (${user.email})`);
    res.status(201).json({ user: safeUser(user) });
  } catch (e) {
    if (e.code === 11000) return res.status(409).json({ message: "Email is already registered." });
    if (e.name === "ValidationError") return res.status(400).json({ message: Object.values(e.errors)[0].message });
    next(e);
  }
});

router.patch("/admin/users/:id", async (req, res, next) => {
  try {
    if (!mongoose.isValidObjectId(req.params.id)) return res.status(404).json({ message: "User not found." });
    const isSelf = String(req.user._id) === req.params.id;
    const update = {};
    for (const k of ["name", "phone", "role", "status", "age", "heightCm", "currentWeight", "fitnessGoal"]) if (req.body[k] !== undefined) update[k] = req.body[k];
    for (const k of ["age", "heightCm", "currentWeight"]) {
      if (update[k] === "") update[k] = null;
      else if (update[k] !== undefined && update[k] !== null) update[k] = Number(update[k]);
    }
    if (req.body.email !== undefined) {
      const email = String(req.body.email).trim().toLowerCase();
      if (!EMAIL.test(email)) return res.status(400).json({ message: "Enter a valid email address." });
      update.email = email;
    }
    if (update.name !== undefined && String(update.name).trim().length < 2) return res.status(400).json({ message: "Name must contain at least 2 characters." });
    if (isSelf && update.role && update.role !== "admin") return res.status(400).json({ message: "You cannot remove your own admin role." });
    if (isSelf && update.status === "suspended") return res.status(400).json({ message: "You cannot suspend your own account." });
    if (req.body.password) {
      if (String(req.body.password).length < 8) return res.status(400).json({ message: "Password must be at least 8 characters." });
      update.password = await bcrypt.hash(String(req.body.password), 12);
    }
    const user = await User.findByIdAndUpdate(req.params.id, update, { new: true, runValidators: true });
    if (!user) return res.status(404).json({ message: "User not found." });
    const what = update.status ? `Set status to ${update.status}` : update.role ? `Changed role to ${update.role}` : req.body.password ? "Reset password" : "Edited user";
    await audit(req, what, `${user.name} (${user.email})`);
    res.json({ user: safeUser(user) });
  } catch (e) {
    if (e.code === 11000) return res.status(409).json({ message: "Email is already registered." });
    if (e.name === "ValidationError") return res.status(400).json({ message: Object.values(e.errors)[0].message });
    next(e);
  }
});

router.delete("/admin/users/:id", async (req, res, next) => {
  try {
    if (!mongoose.isValidObjectId(req.params.id)) return res.status(404).json({ message: "User not found." });
    if (String(req.user._id) === req.params.id) return res.status(400).json({ message: "You cannot delete your own admin account." });
    const user = await User.findByIdAndDelete(req.params.id);
    if (!user) return res.status(404).json({ message: "User not found." });
    await Promise.all([FitnessRecord.deleteMany({ owner: user._id }), Ticket.deleteMany({ owner: user._id })]);
    await audit(req, "Deleted user", `${user.name} (${user.email})`);
    res.json({ message: "User and related data deleted." });
  } catch (e) { next(e); }
});

/* ---------------------------- Notifications ---------------------------- */
router.get("/admin/notifications", async (_req, res, next) => {
  try {
    const groups = await FitnessRecord.aggregate([
      { $match: { type: "notification" } },
      { $sort: { createdAt: -1 } },
      { $group: {
          _id: { $ifNull: ["$batch", { $toString: "$_id" }] }, title: { $first: "$title" }, details: { $first: "$details" },
          createdAt: { $first: "$createdAt" }, recipients: { $sum: 1 }, readCount: { $sum: { $cond: ["$read", 1, 0] } }
      } },
      { $sort: { createdAt: -1 } }, { $limit: 200 }
    ]);
    res.json({ notifications: groups.map((g) => ({ id: g._id, title: g.title, message: g.details?.message || "", category: g.details?.category || "announcement", audience: g.details?.audience || "", createdAt: g.createdAt, recipients: g.recipients, readCount: g.readCount })) });
  } catch (e) { next(e); }
});

router.post("/admin/notifications", async (req, res, next) => {
  try {
    const title = String(req.body.title || "").trim();
    const message = String(req.body.message || "").trim();
    if (!title) return res.status(400).json({ message: "A title is required." });
    if (!message) return res.status(400).json({ message: "A message is required." });
    const category = ["announcement", "reminder", "alert", "achievement"].includes(req.body.category) ? req.body.category : "announcement";
    const audience = ["all", "clients", "user"].includes(req.body.audience) ? req.body.audience : "all";

    let filter = {};
    if (audience === "clients") filter = { role: "client", status: "active" };
    else if (audience === "all") filter = { status: "active" };
    else {
      if (!mongoose.isValidObjectId(req.body.owner)) return res.status(400).json({ message: "Choose a member to notify." });
      filter = { _id: req.body.owner };
    }
    const recipients = await User.find(filter, "_id");
    if (!recipients.length) return res.status(400).json({ message: "No recipients match this audience." });
    const batch = crypto.randomUUID();
    await FitnessRecord.insertMany(recipients.map((u) => ({ owner: u._id, type: "notification", title, date: new Date(), batch, details: { message, category, audience }, read: false })));
    await audit(req, "Sent notification", `${title} → ${recipients.length} recipient(s)`);
    res.status(201).json({ message: `Notification sent to ${recipients.length} account(s).`, recipients: recipients.length });
  } catch (e) { next(e); }
});

router.delete("/admin/notifications/:id", async (req, res, next) => {
  try {
    const or = [{ batch: req.params.id }];
    if (mongoose.isValidObjectId(req.params.id)) or.push({ _id: req.params.id });
    const result = await FitnessRecord.deleteMany({ type: "notification", $or: or });
    if (!result.deletedCount) return res.status(404).json({ message: "Notification not found." });
    await audit(req, "Deleted notification", `${result.deletedCount} copies`);
    res.json({ message: "Notification deleted." });
  } catch (e) { next(e); }
});

/* -------------------------------- Support ------------------------------- */
router.get("/admin/tickets", async (req, res, next) => {
  try {
    const filter = {};
    if (["open", "in_progress", "resolved"].includes(req.query.status)) filter.status = req.query.status;
    if (["low", "medium", "high"].includes(req.query.priority)) filter.priority = req.query.priority;
    if (req.query.q) {
      const rx = { $regex: escapeRegex(String(req.query.q).slice(0, 80)), $options: "i" };
      filter.$or = [{ subject: rx }, { message: rx }];
    }
    const [tickets, groups] = await Promise.all([
      Ticket.find(filter).sort({ updatedAt: -1 }).limit(200).populate("owner", "name email profileImage"),
      Ticket.aggregate([{ $group: { _id: "$status", count: { $sum: 1 } } }])
    ]);
    res.json({ tickets, counts: Object.fromEntries(groups.map((g) => [g._id, g.count])) });
  } catch (e) { next(e); }
});

router.patch("/admin/tickets/:id", async (req, res, next) => {
  try {
    if (!mongoose.isValidObjectId(req.params.id)) return res.status(404).json({ message: "Ticket not found." });
    const ticket = await Ticket.findById(req.params.id);
    if (!ticket) return res.status(404).json({ message: "Ticket not found." });
    if (["open", "in_progress", "resolved"].includes(req.body.status)) ticket.status = req.body.status;
    if (["low", "medium", "high"].includes(req.body.priority)) ticket.priority = req.body.priority;
    const reply = String(req.body.reply || "").trim();
    if (reply) {
      ticket.replies.push({ author: req.user._id, authorName: req.user.name, role: "admin", message: reply });
      if (ticket.status === "open" && !req.body.status) ticket.status = "in_progress";
      await FitnessRecord.create({ owner: ticket.owner, type: "notification", title: `Support replied: ${ticket.subject}`.slice(0, 120), details: { message: reply.slice(0, 500), category: "support" } });
    }
    await ticket.save();
    await audit(req, reply ? "Replied to ticket" : "Updated ticket", ticket.subject);
    await ticket.populate("owner", "name email profileImage");
    res.json({ ticket });
  } catch (e) { next(e); }
});

router.delete("/admin/tickets/:id", async (req, res, next) => {
  try {
    if (!mongoose.isValidObjectId(req.params.id)) return res.status(404).json({ message: "Ticket not found." });
    const ticket = await Ticket.findByIdAndDelete(req.params.id);
    if (!ticket) return res.status(404).json({ message: "Ticket not found." });
    await audit(req, "Deleted ticket", ticket.subject);
    res.json({ message: "Ticket deleted." });
  } catch (e) { next(e); }
});

/* -------------------------------- Reports ------------------------------- */
const TITLES = { users: "Users", tickets: "Support tickets", exercise: "Exercises", workout: "Workouts", weight: "Weight records", measurement: "Body measurements", performance: "Performance", food: "Nutrition", goal: "Goals" };

// ?format=csv (default) downloads a CSV file; ?format=json returns {title, columns, rows} for printable PDF reports.
router.get("/admin/export/:what", async (req, res, next) => {
  try {
    const { what } = req.params;
    if (!TITLES[what]) return res.status(404).json({ message: "Unknown report." });
    const range = {};
    if (req.query.from && !isNaN(new Date(req.query.from))) range.$gte = new Date(req.query.from);
    if (req.query.to && !isNaN(new Date(req.query.to))) { const t = new Date(req.query.to); t.setHours(23, 59, 59, 999); range.$lte = t; }
    let columns, rows;

    if (what === "users") {
      const users = await User.find(userFilter(req.query)).sort({ createdAt: -1 }).limit(5000);
      columns = ["Name", "Email", "Role", "Status", "Phone", "Age", "Height (cm)", "Weight (kg)", "Goal", "Joined", "Last login"];
      rows = users.map((u) => [u.name, u.email, u.role, u.status, u.phone, u.age, u.heightCm, u.currentWeight, u.fitnessGoal, u.createdAt, u.lastLoginAt]);
    } else if (what === "tickets") {
      const filter = Object.keys(range).length ? { createdAt: range } : {};
      const tickets = await Ticket.find(filter).sort({ createdAt: -1 }).limit(5000).populate("owner", "name email");
      columns = ["Subject", "Member", "Email", "Category", "Priority", "Status", "Replies", "Created"];
      rows = tickets.map((t) => [t.subject, t.owner?.name, t.owner?.email, t.category, t.priority, t.status, t.replies.length, t.createdAt]);
    } else {
      const filter = { type: what };
      if (Object.keys(range).length) filter.date = range;
      const records = await FitnessRecord.find(filter).sort({ date: -1 }).limit(5000).populate("owner", "name email");
      const keys = [...new Set(records.flatMap((r) => Object.keys(r.details || {})))];
      columns = ["Date", "Title", "Member", "Email", ...keys.map((k) => k.replace(/([A-Z])/g, " $1").replace(/^./, (c) => c.toUpperCase()))];
      rows = records.map((r) => [r.date, r.title, r.owner?.name || "Shared library", r.owner?.email || "", ...keys.map((k) => r.details?.[k] ?? "")]);
    }
    await audit(req, "Exported report", TITLES[what]);

    if (req.query.format === "json") {
      const fmt = (v) => (v instanceof Date ? v.toISOString().slice(0, 10) : v ?? "");
      return res.json({ title: TITLES[what], columns, rows: rows.map((r) => r.map(fmt)) });
    }
    res.setHeader("Content-Type", "text/csv; charset=utf-8");
    res.setHeader("Content-Disposition", `attachment; filename="fitzone-${what}-${new Date().toISOString().slice(0, 10)}.csv"`);
    res.send("\uFEFF" + toCsv(columns, rows));
  } catch (e) { next(e); }
});

module.exports = router;
