const express = require("express");
const { protect, allowRoles } = require("../middleware/auth");
const User = require("../models/User");
const router = express.Router();

router.get("/admin/stats", protect, allowRoles("admin"), async (req, res, next) => {
  try {
    const [totalUsers, clients, admins] = await Promise.all([
      User.countDocuments(), User.countDocuments({ role: "client" }), User.countDocuments({ role: "admin" })
    ]);
    res.json({ message: "Admin dashboard data loaded.", stats: { totalUsers, clients, admins } });
  } catch (error) { next(error); }
});

router.get("/client/dashboard", protect, allowRoles("client"), (req, res) => {
  res.json({
    message: `Welcome back, ${req.user.name}.`,
    tips: [
      "Warm up for 5–10 minutes before training.",
      "Use progressive overload and track your workouts.",
      "Prioritize sleep, hydration, and consistent nutrition."
    ]
  });
});

module.exports = router;
