const express = require("express");
const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");
const User = require("../models/User");
const FitnessRecord = require("../models/FitnessRecord");
const Ticket = require("../models/Ticket");
const { protect } = require("../middleware/auth");
const { safeUser } = require("../controllers/authController");

const router = express.Router();
const TYPES = ["exercise", "workout", "weight", "measurement", "performance", "food", "goal", "notification"];
router.use(protect);

const escapeRegex = (text) => String(text).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

// details is free-form, but it must be a flat-ish plain object with bounded values.
function cleanDetails(input) {
  if (!input || typeof input !== "object" || Array.isArray(input)) return {};
  const out = {};
  for (const [key, value] of Object.entries(input).slice(0, 30)) {
    if (!/^[A-Za-z][A-Za-z0-9_]{0,40}$/.test(key)) continue;
    out[key] = typeof value === "string" ? value.trim().slice(0, 2000) : typeof value === "number" || typeof value === "boolean" ? value : "";
  }
  return out;
}

/* ---------------------------- Own account ---------------------------- */
router.patch("/users/me", async (req, res, next) => {
  try {
    const update = {};
    for (const k of ["name", "phone", "age", "heightCm", "currentWeight", "fitnessGoal", "profileImage"]) {
      if (req.body[k] !== undefined) update[k] = req.body[k];
    }
    if (update.name !== undefined && String(update.name).trim().length < 2) {
      return res.status(400).json({ message: "Name must contain at least 2 characters." });
    }
    if (update.profileImage && (!String(update.profileImage).startsWith("data:image/") || String(update.profileImage).length > 3000000)) {
      return res.status(400).json({ message: "Profile image must be an image smaller than 2 MB." });
    }
    for (const k of ["age", "heightCm", "currentWeight"]) {
      if (update[k] === "") update[k] = null;
      else if (update[k] !== undefined && update[k] !== null) update[k] = Number(update[k]);
    }
    const prefs = req.body.preferences;
    if (prefs && typeof prefs === "object") {
      if (["dark", "light"].includes(prefs.theme)) update["preferences.theme"] = prefs.theme;
      if (["metric", "imperial"].includes(prefs.units)) update["preferences.units"] = prefs.units;
      if (typeof prefs.emailNotifications === "boolean") update["preferences.emailNotifications"] = prefs.emailNotifications;
      if (typeof prefs.workoutReminders === "boolean") update["preferences.workoutReminders"] = prefs.workoutReminders;
    }
    const user = await User.findByIdAndUpdate(req.user._id, update, { new: true, runValidators: true });
    res.json({ message: "Profile updated.", user: safeUser(user) });
  } catch (e) { next(e); }
});

router.patch("/users/me/password", async (req, res, next) => {
  try {
    const user = await User.findById(req.user._id).select("+password");
    if (!req.body.currentPassword || !(await bcrypt.compare(req.body.currentPassword, user.password))) {
      return res.status(400).json({ message: "Current password is incorrect." });
    }
    if (!req.body.newPassword || String(req.body.newPassword).length < 8) {
      return res.status(400).json({ message: "New password must be at least 8 characters." });
    }
    user.password = await bcrypt.hash(req.body.newPassword, 12);
    await user.save();
    res.json({ message: "Password changed successfully." });
  } catch (e) { next(e); }
});

router.delete("/users/me", async (req, res, next) => {
  try {
    if (req.user.role === "admin" && (await User.countDocuments({ role: "admin" })) <= 1) {
      return res.status(400).json({ message: "You are the only administrator. Promote another admin before deleting this account." });
    }
    await User.findByIdAndDelete(req.user._id);
    await Promise.all([FitnessRecord.deleteMany({ owner: req.user._id }), Ticket.deleteMany({ owner: req.user._id })]);
    res.json({ message: "Account deleted." });
  } catch (e) { next(e); }
});

/* ---------------------------- Fitness records ---------------------------- */
router.get("/fitness/:type", async (req, res, next) => {
  try {
    const { type } = req.params;
    if (!TYPES.includes(type)) return res.status(404).json({ message: "Unknown fitness section." });
    const isAdminView = req.user.role === "admin" && req.query.all === "true";
    let filter = { type };

    if (!isAdminView) {
      if (type === "exercise" || type === "workout") {
        // Members see their own entries plus the shared library curated by admins.
        const admins = await User.find({ role: "admin" }).distinct("_id");
        filter = { type, $or: [{ owner: req.user._id }, { owner: { $in: admins } }] };
      } else {
        filter = { type, owner: req.user._id };
      }
    } else {
      if (req.query.owner && mongoose.isValidObjectId(req.query.owner)) filter.owner = req.query.owner;
    }

    if (req.query.q) filter.title = { $regex: escapeRegex(String(req.query.q).slice(0, 80)), $options: "i" };
    const from = req.query.from ? new Date(req.query.from) : null;
    const to = req.query.to ? new Date(req.query.to) : null;
    if ((from && !isNaN(from)) || (to && !isNaN(to))) {
      filter.date = {};
      if (from && !isNaN(from)) filter.date.$gte = from;
      if (to && !isNaN(to)) { to.setHours(23, 59, 59, 999); filter.date.$lte = to; }
    }

    const limit = Math.min(Math.max(parseInt(req.query.limit, 10) || 500, 1), 1000);
    const records = await FitnessRecord.find(filter)
      .populate("owner", "name email role")
      .sort({ date: -1, createdAt: -1 })
      .limit(limit);
    res.json({ records });
  } catch (e) { next(e); }
});

router.post("/fitness/:type", async (req, res, next) => {
  try {
    const { type } = req.params;
    if (!TYPES.includes(type)) return res.status(404).json({ message: "Unknown fitness section." });
    const title = String(req.body.title || "").trim();
    if (!title) return res.status(400).json({ message: "A title is required." });

    let owner = req.user._id;
    if (req.user.role === "admin" && req.body.owner) {
      if (!mongoose.isValidObjectId(req.body.owner) || !(await User.exists({ _id: req.body.owner }))) {
        return res.status(400).json({ message: "Selected member does not exist." });
      }
      owner = req.body.owner;
    }
    const record = await FitnessRecord.create({ owner, type, title, date: req.body.date || Date.now(), details: cleanDetails(req.body.details), read: false });
    res.status(201).json({ record });
  } catch (e) { next(e); }
});

router.patch("/fitness/:type/:id", async (req, res, next) => {
  try {
    if (!TYPES.includes(req.params.type) || !mongoose.isValidObjectId(req.params.id)) return res.status(404).json({ message: "Record not found." });
    const filter = { _id: req.params.id, type: req.params.type };
    if (req.user.role !== "admin") filter.owner = req.user._id;
    const update = {};
    for (const k of ["title", "date", "read"]) if (req.body[k] !== undefined) update[k] = req.body[k];
    if (req.body.details !== undefined) update.details = cleanDetails(req.body.details);
    if (req.user.role === "admin" && req.body.owner && mongoose.isValidObjectId(req.body.owner)) update.owner = req.body.owner;
    else if (req.user.role === "admin" && req.body.owner === "") update.owner = req.user._id; // back to the shared library
    const record = await FitnessRecord.findOneAndUpdate(filter, update, { new: true, runValidators: true });
    if (!record) return res.status(404).json({ message: "Record not found." });
    res.json({ record });
  } catch (e) { next(e); }
});

router.delete("/fitness/:type/:id", async (req, res, next) => {
  try {
    if (!TYPES.includes(req.params.type) || !mongoose.isValidObjectId(req.params.id)) return res.status(404).json({ message: "Record not found." });
    const filter = { _id: req.params.id, type: req.params.type };
    if (req.user.role !== "admin") filter.owner = req.user._id;
    const record = await FitnessRecord.findOneAndDelete(filter);
    if (!record) return res.status(404).json({ message: "Record not found." });
    res.json({ message: "Record deleted." });
  } catch (e) { next(e); }
});

module.exports = router;
module.exports.TYPES = TYPES;
