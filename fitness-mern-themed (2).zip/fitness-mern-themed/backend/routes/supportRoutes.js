const express = require("express");
const mongoose = require("mongoose");
const Ticket = require("../models/Ticket");
const { protect } = require("../middleware/auth");

const router = express.Router();
router.use(protect);

// Members: list their own tickets
router.get("/mine", async (req, res, next) => {
  try {
    const tickets = await Ticket.find({ owner: req.user._id }).sort({ updatedAt: -1 }).limit(100);
    res.json({ tickets });
  } catch (e) { next(e); }
});

// Members: open a ticket / send feedback
router.post("/", async (req, res, next) => {
  try {
    const subject = String(req.body.subject || "").trim();
    const message = String(req.body.message || "").trim();
    if (subject.length < 3) return res.status(400).json({ message: "Subject must contain at least 3 characters." });
    if (message.length < 10) return res.status(400).json({ message: "Please describe your request in at least 10 characters." });
    const category = ["issue", "feedback", "question", "other"].includes(req.body.category) ? req.body.category : "question";
    const priority = ["low", "medium", "high"].includes(req.body.priority) ? req.body.priority : "medium";
    const ticket = await Ticket.create({ owner: req.user._id, subject, message, category, priority });
    res.status(201).json({ ticket });
  } catch (e) { next(e); }
});

// Members: add a follow-up to their own ticket
router.post("/:id/reply", async (req, res, next) => {
  try {
    if (!mongoose.isValidObjectId(req.params.id)) return res.status(404).json({ message: "Ticket not found." });
    const message = String(req.body.message || "").trim();
    if (!message) return res.status(400).json({ message: "Reply cannot be empty." });
    const ticket = await Ticket.findOne({ _id: req.params.id, owner: req.user._id });
    if (!ticket) return res.status(404).json({ message: "Ticket not found." });
    ticket.replies.push({ author: req.user._id, authorName: req.user.name, role: "client", message });
    if (ticket.status === "resolved") ticket.status = "open";
    await ticket.save();
    res.json({ ticket });
  } catch (e) { next(e); }
});

module.exports = router;
