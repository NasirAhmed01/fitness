require("dotenv").config();
const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");
const User = require("../models/User");

async function run() {
  if (!process.env.MONGODB_URI || !process.env.ADMIN_EMAIL || !process.env.ADMIN_PASSWORD) {
    throw new Error("Set MONGODB_URI, ADMIN_EMAIL and ADMIN_PASSWORD in .env first.");
  }
  if (process.env.ADMIN_PASSWORD.length < 12) {
    throw new Error("Set ADMIN_PASSWORD to at least 12 characters before seeding.");
  }
  await mongoose.connect(process.env.MONGODB_URI);
  const email = process.env.ADMIN_EMAIL.toLowerCase().trim();
  const password = await bcrypt.hash(process.env.ADMIN_PASSWORD, 12);
  const admin = await User.findOneAndUpdate(
    { email },
    { $set: { name: process.env.ADMIN_NAME || "FitZone Admin", email, password, role: "admin" } },
    { new: true, upsert: true, runValidators: true, setDefaultsOnInsert: true }
  );
  console.log(`Admin account ready: ${admin.email}`);
  await mongoose.disconnect();
}
run().catch(async (err) => { console.error(err.message); try { await mongoose.disconnect(); } catch {} process.exit(1); });
