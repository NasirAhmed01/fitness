require("dotenv").config();
const express = require("express");
const cors = require("cors");
const rateLimit = require("express-rate-limit");
const connectDB = require("./config/db");
const dns = require("node:dns");
dns.setServers(["8.8.8.8", "1.1.1.1"]);
const app = express();
app.disable("x-powered-by");
app.use(cors({ origin: process.env.CLIENT_URL || "http://localhost:5173" }));
app.use(express.json({ limit: "4mb" }));
app.use("/api/auth", rateLimit({ windowMs: 15 * 60 * 1000, limit: 100, standardHeaders: true, legacyHeaders: false }));

app.get("/api/health", (_req, res) => res.json({ status: "ok", service: "FitZone API" }));
app.use("/api/auth", require("./routes/authRoutes"));
app.use("/api", require("./routes/dashboardRoutes"));
app.use("/api/support", require("./routes/supportRoutes"));
app.use("/api", require("./routes/adminRoutes"));
app.use("/api", require("./routes/fitnessRoutes"));

app.use((req, res) => res.status(404).json({ message: "API route not found." }));
app.use((err, _req, res, _next) => {
  console.error(err);
  res.status(500).json({ message: "Server error. Please try again." });
});

const port = process.env.PORT || 5000;
connectDB().then(() => app.listen(port, () => console.log(`FitZone API running on http://localhost:${port}`)))
  .catch((err) => { console.error("Startup failed:", err.message); process.exit(1); });



// cd backend
// npm install
// copy .env.example .env

// Edit backend/.env and configure your MongoDB connection and secrets. Then run:
// npm run seed:admin
// npm run dev
// Terminal 2 — Frontend
// cd frontend
// npm install
// copy .env.example .env
// npm run dev

// then paste this 
// node -e "const dns=require('node:dns');dns.setServers(['8.8.8.8','1.1.1.1']);dns.resolveSrv('_mongodb._tcp.nasir.m6a4cuc.mongodb.net',(e,a)=>console.log(e||a))"
// node server.js