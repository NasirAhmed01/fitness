const AuditLog = require("../models/AuditLog");

// Records an admin action. Logging must never break the request, so errors are swallowed.
module.exports = async function audit(req, action, target = "") {
  try {
    await AuditLog.create({ actor: req.user._id, actorName: req.user.name, action, target: String(target).slice(0, 200) });
  } catch (error) {
    console.error("Audit log failed:", error.message);
  }
};
