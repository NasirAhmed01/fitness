// Minimal CSV builder. Cells that start with a spreadsheet formula character are prefixed
// with an apostrophe so exported data cannot execute formulas when opened in Excel.
function cell(value) {
  if (value === null || value === undefined) return "";
  let text = value instanceof Date ? value.toISOString().slice(0, 10) : String(value);
  if (/^[=+\-@\t\r]/.test(text)) text = `'${text}`;
  return /[",\n\r]/.test(text) ? `"${text.replace(/"/g, '""')}"` : text;
}

function toCsv(columns, rows) {
  return [columns, ...rows].map((row) => row.map(cell).join(",")).join("\r\n");
}

module.exports = { toCsv };
