import { Navigate, Route, Routes } from "react-router-dom";
import { AuthProvider } from "./auth/AuthContext";
import ProtectedRoute from "./components/ProtectedRoute";
import RoleRedirect from "./components/RoleRedirect";
import Home from "./pages/Home";
import Login from "./pages/Login";
import Register from "./pages/Register";
import ClientDashboard from "./pages/ClientDashboard";
import Profile from "./pages/Profile";
import FitnessPage from "./pages/FitnessPage";
import Support from "./pages/Support";
import AdminLayout from "./admin/AdminLayout";
import AdminDashboard from "./admin/Dashboard";
import AdminUsers from "./admin/Users";
import AdminRecords from "./admin/Records";
import AdminNotifications from "./admin/Notifications";
import AdminSupport from "./admin/Support";
import AdminReports from "./admin/Reports";
import AdminSettings from "./admin/Settings";

function RouteTree() {
  return <Routes>
    <Route path="/" element={<Home />} />
    <Route path="/login" element={<Login />} />
    <Route path="/register" element={<Register />} />
    <Route element={<ProtectedRoute roles={["client"]} />}><Route path="/client/dashboard" element={<ClientDashboard />} /><Route path="/client/profile" element={<Profile />} /><Route path="/client/support" element={<Support />} /><Route path="/client/:section" element={<FitnessPage />} /></Route>
    <Route element={<ProtectedRoute roles={["admin"]} />}><Route element={<AdminLayout />}>
      <Route path="/admin/dashboard" element={<AdminDashboard />} />
      <Route path="/admin/users" element={<AdminUsers />} />
      <Route path="/admin/notification" element={<AdminNotifications />} />
      <Route path="/admin/support" element={<AdminSupport />} />
      <Route path="/admin/reports" element={<AdminReports />} />
      <Route path="/admin/settings" element={<AdminSettings />} />
      <Route path="/admin/profile" element={<Navigate to="/admin/settings" replace />} />
      <Route path="/admin/:section" element={<AdminRecords />} />
    </Route></Route>
    <Route path="/dashboard" element={<RoleRedirect />} />
    <Route path="*" element={<Navigate to="/" replace />} />
  </Routes>;
}
export default function App() {
  return <AuthProvider><RouteTree /></AuthProvider>;
}
