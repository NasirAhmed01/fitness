import { useEffect, useState } from "react";
import { NavLink, Outlet, useLocation, useNavigate } from "react-router-dom";
import { useAuth } from "../auth/AuthContext";
import api from "../api";
import { Avatar, AdminUIProvider, Icon } from "./ui";
import "./admin.css";

const NAV = [
  { label: "Overview", items: [["dashboard", "Dashboard", "dashboard"]] },
  { label: "Management", items: [["users", "Users", "users"], ["notification", "Notifications", "bell"], ["support", "Support", "lifebuoy"]] },
  { label: "Fitness data", items: [["exercise", "Exercises", "dumbbell"], ["workout", "Workouts", "workout"], ["weight", "Weight", "gauge"], ["measurement", "Measurements", "ruler"], ["performance", "Performance", "activity"], ["food", "Nutrition", "utensils"], ["goal", "Goals", "target"]] },
  { label: "Insights", items: [["reports", "Reports & export", "file"]] },
  { label: "Account", items: [["settings", "Settings", "settings"]] }
];
const TITLES = Object.fromEntries(NAV.flatMap((g) => g.items.map(([p, l]) => [p, l])));

export default function AdminLayout() {
  const { user, setUser, logout } = useAuth();
  const navigate = useNavigate();
  const { pathname } = useLocation();
  const [open, setOpen] = useState(false);
  const [badge, setBadge] = useState(0);
  const [theme, setThemeState] = useState(() => localStorage.getItem("fitzone_admin_theme") || user?.preferences?.theme || "dark");

  useEffect(() => { setOpen(false); window.scrollTo(0, 0); }, [pathname]);
  useEffect(() => {
    let alive = true;
    const load = () => api.get("/admin/badges").then((r) => alive && setBadge(r.data.openTickets)).catch(() => {});
    load();
    const id = setInterval(load, 60000);
    return () => { alive = false; clearInterval(id); };
  }, [pathname]);

  function setTheme(next) {
    setThemeState(next);
    localStorage.setItem("fitzone_admin_theme", next);
    api.patch("/users/me", { preferences: { theme: next } }).then((r) => setUser(r.data.user)).catch(() => {});
  }
  const page = TITLES[pathname.split("/")[2]] || "Admin";

  return <AdminUIProvider>
    <div className="adm" data-theme={theme}>
      <aside className={`adm-side${open ? " open" : ""}`}>
        <div className="adm-brand"><span className="adm-brand-mark">F</span><div>FitZone<small>ADMIN CONSOLE</small></div></div>
        <nav className="adm-nav" aria-label="Admin navigation">
          {NAV.map((g) => <div key={g.label}>
            <div className="adm-nav-label">{g.label}</div>
            {g.items.map(([path, label, icon]) => <NavLink key={path} to={`/admin/${path}`} className={({ isActive }) => `adm-link${isActive ? " active" : ""}`}>
              <Icon name={icon} size={18} />{label}{path === "support" && badge > 0 && <span className="adm-count">{badge}</span>}
            </NavLink>)}
          </div>)}
        </nav>
        <div className="adm-side-user">
          <Avatar user={user} size={38} />
          <div><strong>{user?.name}</strong><small>Administrator</small></div>
          <button className="adm-iconbtn" title="Log out" aria-label="Log out" onClick={() => { logout(); navigate("/"); }}><Icon name="logout" size={16} /></button>
        </div>
      </aside>
      <div className={`adm-scrim${open ? " show" : ""}`} onClick={() => setOpen(false)} />
      <div className="adm-main">
        <header className="adm-top">
          <button className="adm-iconbtn adm-menu-btn" aria-label="Open menu" onClick={() => setOpen(true)}><Icon name="menu" /></button>
          <div className="adm-crumb">Admin / <b>{page}</b></div>
          <div className="adm-spacer" />
          <NavLink to="/admin/support" className="adm-iconbtn" title="Open support tickets" aria-label="Support tickets"><Icon name="bell" size={17} />{badge > 0 && <span className="adm-dot">{badge}</span>}</NavLink>
          <button className="adm-iconbtn" title="Toggle theme" aria-label="Toggle light or dark theme" onClick={() => setTheme(theme === "dark" ? "light" : "dark")}><Icon name={theme === "dark" ? "sun" : "moon"} size={17} /></button>
          <NavLink to="/admin/settings" className="adm-iconbtn" aria-label="Profile settings" style={{ padding: 0, overflow: "hidden" }}><Avatar user={user} size={36} /></NavLink>
        </header>
        <main className="adm-content"><Outlet context={{ theme, setTheme }} /></main>
      </div>
    </div>
  </AdminUIProvider>;
}
