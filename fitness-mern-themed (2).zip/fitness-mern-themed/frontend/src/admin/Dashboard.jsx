import { useCallback, useEffect, useState } from "react";
import { Link } from "react-router-dom";
import api from "../api";
import { useAuth } from "../auth/AuthContext";
import { AreaChart, BarChart, BarList, Donut } from "./charts";
import { Alert, Avatar, Badge, Icon, PageHeader, Skeleton } from "./ui";
import { errorText, timeAgo } from "./utils";

const TYPE_META = {
  exercise: ["Exercises", "dumbbell", "var(--accent)"], workout: ["Workouts", "workout", "var(--info)"], weight: ["Weight", "gauge", "var(--ok)"],
  measurement: ["Measurements", "ruler", "var(--violet)"], performance: ["Performance", "activity", "var(--warn)"], food: ["Nutrition", "utensils", "var(--bad)"], goal: ["Goals", "target", "#2dd4bf"]
};

function Kpi({ icon, tone, label, value, hint, to }) {
  const body = <div className="adm-card adm-kpi"><span className={`adm-kpi-ico tone-${tone}`}><Icon name={icon} size={21} /></span><div><small>{label}</small><strong>{value ?? "—"}</strong><span>{hint}</span></div></div>;
  return to ? <Link to={to}>{body}</Link> : body;
}
function Card({ title, sub, action, children }) {
  return <section className="adm-card"><div className="adm-card-h"><div><h2>{title}</h2>{sub && <small>{sub}</small>}</div>{action}</div><div className="adm-card-b">{children}</div></section>;
}

export default function Dashboard() {
  const { user } = useAuth();
  const [data, setData] = useState(null);
  const [error, setError] = useState("");
  const load = useCallback(() => { setError(""); api.get("/admin/analytics").then((r) => setData(r.data)).catch((e) => setError(errorText(e, "Unable to load analytics."))); }, []);
  useEffect(load, [load]);
  const k = data?.kpis;
  const hour = new Date().getHours();
  const greeting = hour < 12 ? "Good morning" : hour < 18 ? "Good afternoon" : "Good evening";

  return <>
    <PageHeader title="Dashboard" subtitle="Live overview of members, fitness activity and support across FitZone.">
      <button className="adm-btn" onClick={load}><Icon name="refresh" size={15} />Refresh</button>
    </PageHeader>
    {error && <Alert>{error}</Alert>}

    <section className="adm-card adm-welcome">
      <div style={{ position: "relative", zIndex: 1 }}><h2>{greeting}, {user?.name?.split(" ")[0]} 👋</h2>
        <p>{k ? `${k.newThisWeek} new member${k.newThisWeek === 1 ? "" : "s"} this week and ${k.openTickets} open support request${k.openTickets === 1 ? "" : "s"}.` : "Loading your platform summary…"}</p></div>
      <div className="adm-actions"><Link className="adm-btn dark" to="/admin/users"><Icon name="plus" size={15} />Add user</Link><Link className="adm-btn" to="/admin/notification"><Icon name="send" size={15} />Send announcement</Link></div>
    </section>

    <div className="adm-grid g4">
      <Kpi icon="users" tone="accent" label="Total members" value={k?.totalUsers} hint={k ? `${k.clients} clients · ${k.admins} admins` : ""} to="/admin/users" />
      <Kpi icon="trend" tone="ok" label="New this week" value={k?.newThisWeek} hint="Registrations in the last 7 days" />
      <Kpi icon="activity" tone="info" label="Tracked records" value={k?.totalRecords} hint="Workouts, meals, goals & more" />
      <Kpi icon="lifebuoy" tone={k?.openTickets ? "warn" : "muted"} label="Open support" value={k?.openTickets} hint={k ? `${k.suspended} suspended account${k.suspended === 1 ? "" : "s"}` : ""} to="/admin/support" />
    </div>

    <div className="adm-grid g-2-1">
      <Card title="Platform activity" sub="Records logged per day · last 14 days">{data ? <AreaChart data={data.activity} /> : <Skeleton h={230} />}</Card>
      <Card title="Records by category" sub="All time">{data ? <Donut size={150} thickness={18} center={{ value: k.totalRecords, label: "records" }} segments={data.byType.map((t) => ({ label: TYPE_META[t.type][0], value: t.count, color: TYPE_META[t.type][2] }))} /> : <Skeleton h={160} />}</Card>
    </div>

    <div className="adm-grid g-2-1">
      <Card title="Member growth" sub="New registrations · last 6 months">{data ? <BarChart data={data.signups} /> : <Skeleton h={230} />}</Card>
      <Card title="Nutrition snapshot" sub="Food logs · last 14 days">
        {!data ? <Skeleton h={160} /> : data.macros.entries === 0 ? <p style={{ color: "var(--muted)" }}>No food entries logged in the last 14 days.</p> : <>
          <Donut size={130} thickness={16} center={{ value: data.macros.avgCalories, label: "avg kcal" }} segments={[
            { label: "Protein", value: data.macros.protein, color: "var(--accent)", suffix: " g" }, { label: "Carbs", value: data.macros.carbs, color: "var(--info)", suffix: " g" }, { label: "Fats", value: data.macros.fats, color: "var(--warn)", suffix: " g" }]} />
          <p style={{ color: "var(--muted)", fontSize: 12, marginTop: 12 }}>{data.macros.entries} entries · average calories per entry</p></>}
      </Card>
    </div>

    <div className="adm-grid g3">
      <Card title="Most active members" sub="By tracked records" action={<Link className="adm-btn sm" to="/admin/users">All users</Link>}>
        {!data ? <Skeleton h={180} /> : data.topUsers.length === 0 ? <p style={{ color: "var(--muted)" }}>No activity yet.</p> : <div className="adm-feed">
          {data.topUsers.map((u, i) => <div className="adm-feed-item" key={u.id} style={{ alignItems: "center" }}><span className="adm-rank">{i + 1}</span><Avatar user={u} size={34} /><div style={{ minWidth: 0, flex: 1 }}><strong style={{ whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{u.name}</strong><small>{u.email}</small></div><Badge tone="accent" plain>{u.count}</Badge></div>)}</div>}
      </Card>
      <Card title="Newest members" sub="Latest registrations">
        {!data ? <Skeleton h={180} /> : <div className="adm-feed">{data.recentUsers.map((u) => <div className="adm-feed-item" key={u.id} style={{ alignItems: "center" }}><Avatar user={u} size={34} /><div style={{ minWidth: 0, flex: 1 }}><strong style={{ whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{u.name}</strong><small>{timeAgo(u.createdAt)}</small></div><Badge tone={u.role === "admin" ? "violet" : "info"}>{u.role}</Badge></div>)}</div>}
      </Card>
      <Card title="Recent activity" sub="Latest tracked records">
        {!data ? <Skeleton h={180} /> : data.recentRecords.length === 0 ? <p style={{ color: "var(--muted)" }}>Nothing logged yet.</p> : <div className="adm-feed">{data.recentRecords.slice(0, 6).map((r) => { const m = TYPE_META[r.type]; return <div className="adm-feed-item" key={r.id}><span className="ico tone-muted" style={{ color: m[2] }}><Icon name={m[1]} size={16} /></span><div style={{ minWidth: 0 }}><strong style={{ whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{r.title}</strong><small>{m[0]} · {r.owner} · {timeAgo(r.createdAt)}</small></div></div>; })}</div>}
      </Card>
    </div>

    <div className="adm-grid g-3-2">
      <Card title="Content volume" sub="Records per tracker"><>{data ? <BarList items={data.byType.map((t) => ({ label: TYPE_META[t.type][0], value: t.count, color: TYPE_META[t.type][2] }))} /> : <Skeleton h={200} />}</></Card>
      <Card title="Admin audit log" sub="Latest administrative actions">
        {!data ? <Skeleton h={200} /> : data.logs.length === 0 ? <p style={{ color: "var(--muted)" }}>No admin actions recorded yet.</p> : <div className="adm-feed">{data.logs.map((l) => <div className="adm-feed-item" key={l.id}><span className="ico tone-accent"><Icon name="shield" size={16} /></span><div style={{ minWidth: 0 }}><strong>{l.action}</strong><small>{l.actorName} · {l.target} · {timeAgo(l.createdAt)}</small></div></div>)}</div>}
      </Card>
    </div>
  </>;
}
