import { useCallback, useEffect, useState } from "react";
import api from "../api";
import { Alert, Badge, Empty, Icon, PageHeader, TableSkeleton, useAdminUI } from "./ui";
import { errorText, timeAgo } from "./utils";

const CATS = { announcement: ["Announcement", "info"], reminder: ["Reminder", "warn"], alert: ["Alert", "bad"], achievement: ["Achievement", "ok"], support: ["Support", "violet"] };
const BLANK = { title: "", message: "", category: "announcement", audience: "all", owner: "" };

export default function Notifications() {
  const { toast, confirm } = useAdminUI();
  const [items, setItems] = useState([]);
  const [members, setMembers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [form, setForm] = useState(BLANK);
  const [sending, setSending] = useState(false);
  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));

  const load = useCallback(async () => {
    setLoading(true);
    try { const { data } = await api.get("/admin/notifications"); setItems(data.notifications); setError(""); } catch (e) { setError(errorText(e, "Unable to load notifications.")); } finally { setLoading(false); }
  }, []);
  useEffect(() => { load(); api.get("/admin/users", { params: { limit: 500, sort: "name", dir: "asc" } }).then((r) => setMembers(r.data.users)).catch(() => {}); }, [load]);

  async function send(e) {
    e.preventDefault(); setSending(true);
    try { const { data } = await api.post("/admin/notifications", form); toast(data.message); setForm(BLANK); load(); } catch (err) { toast(errorText(err, "Could not send notification."), "bad"); } finally { setSending(false); }
  }
  async function remove(n) {
    if (!(await confirm({ title: "Delete notification?", message: `“${n.title}” will be removed from ${n.recipients} member inbox${n.recipients === 1 ? "" : "es"}.`, confirmText: "Delete", danger: true }))) return;
    try { await api.delete(`/admin/notifications/${n.id}`); toast("Notification deleted"); load(); } catch (e) { toast(errorText(e), "bad"); }
  }

  return <>
    <PageHeader title="Notifications" subtitle="Broadcast announcements, workout reminders and alerts to members' in-app inbox." />
    {error && <Alert>{error}</Alert>}
    <div className="adm-grid g-2-1" style={{ alignItems: "start" }}>
      <section className="adm-card">
        <div className="adm-card-h"><div><h2>Sent notifications</h2><small>{items.length} total · newest first</small></div><button className="adm-btn sm" onClick={load}><Icon name="refresh" size={14} />Refresh</button></div>
        <div className="adm-card-b" style={{ padding: 0, marginTop: 14 }}>
          {loading ? <TableSkeleton rows={5} /> : items.length === 0 ? <Empty icon="bell" title="No notifications sent yet">Use the form to send your first announcement.</Empty> : <div className="adm-table-wrap"><table className="adm-table" style={{ minWidth: 560 }}>
            <thead><tr><th>Notification</th><th>Type</th><th>Reach</th><th>Sent</th><th /></tr></thead>
            <tbody>{items.map((n) => { const c = CATS[n.category] || CATS.announcement; const pct = n.recipients ? Math.round((n.readCount / n.recipients) * 100) : 0;
              return <tr key={n.id}><td><strong style={{ fontWeight: 600 }}>{n.title}</strong><div className="adm-trunc" style={{ maxWidth: 320 }} title={n.message}>{n.message}</div></td>
                <td><Badge tone={c[1]}>{c[0]}</Badge></td>
                <td className="num">{n.recipients} <span className="muted">· {pct}% read</span></td>
                <td className="muted" style={{ whiteSpace: "nowrap" }}>{timeAgo(n.createdAt)}</td>
                <td><div className="row-actions"><button className="adm-btn sm icon danger" aria-label={`Delete ${n.title}`} onClick={() => remove(n)}><Icon name="trash" size={15} /></button></div></td></tr>; })}</tbody></table></div>}
        </div>
      </section>

      <form className="adm-card" onSubmit={send}>
        <div className="adm-card-h"><div><h2>New notification</h2><small>Delivered instantly to the selected audience</small></div></div>
        <div className="adm-card-b" style={{ display: "flex", flexDirection: "column", gap: 14 }}>
          <label className="adm-field">Title<input className="adm-input" required maxLength={120} placeholder="e.g. New HIIT classes this week" value={form.title} onChange={(e) => set("title", e.target.value)} /></label>
          <label className="adm-field">Message<textarea className="adm-textarea" required maxLength={500} placeholder="Write the message members will see…" value={form.message} onChange={(e) => set("message", e.target.value)} /></label>
          <label className="adm-field">Type<select className="adm-select" value={form.category} onChange={(e) => set("category", e.target.value)}><option value="announcement">Announcement</option><option value="reminder">Reminder</option><option value="alert">Alert</option><option value="achievement">Achievement</option></select></label>
          <label className="adm-field">Audience<select className="adm-select" value={form.audience} onChange={(e) => set("audience", e.target.value)}><option value="all">All active accounts</option><option value="clients">Client members only</option><option value="user">One specific member</option></select></label>
          {form.audience === "user" && <label className="adm-field">Member<select className="adm-select" required value={form.owner} onChange={(e) => set("owner", e.target.value)}><option value="">Select a member…</option>{members.map((m) => <option key={m.id} value={m.id}>{m.name} — {m.email}</option>)}</select></label>}
          <button className="adm-btn primary" disabled={sending}><Icon name="send" size={15} />{sending ? "Sending…" : "Send notification"}</button>
        </div>
      </form>
    </div>
  </>;
}
