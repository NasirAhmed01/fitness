import { useCallback, useEffect, useMemo, useState } from "react";
import { Navigate, useParams } from "react-router-dom";
import api from "../api";
import { Alert, Badge, Empty, Icon, Modal, PageHeader, Pager, Person, TableSkeleton, useAdminUI, useDebounce } from "./ui";
import { downloadReport, errorText, fmtDate } from "./utils";
import { SECTIONS } from "./sections";

const PAGE = 10;
const today = () => new Date().toISOString().slice(0, 10);
const blank = () => ({ title: "", date: today(), owner: "", details: {} });

export default function Records() {
  const { section } = useParams();
  const cfg = SECTIONS[section];
  if (!cfg) return <Navigate to="/admin/dashboard" replace />;
  return <RecordsView key={section} section={section} cfg={cfg} />;
}

function RecordsView({ section, cfg }) {
  const { toast, confirm } = useAdminUI();
  const [records, setRecords] = useState([]);
  const [members, setMembers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [q, setQ] = useState("");
  const [owner, setOwner] = useState("");
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [page, setPage] = useState(1);
  const [form, setForm] = useState(null);
  const [editId, setEditId] = useState(null);
  const [saving, setSaving] = useState(false);
  const [formError, setFormError] = useState("");
  const dq = useDebounce(q);
  const field = (k) => cfg.fields.find((f) => f.k === k);

  const load = useCallback(async () => {
    setLoading(true); setError("");
    try {
      const { data } = await api.get(`/fitness/${section}`, { params: { all: true, q: dq || undefined, owner: owner || undefined, from: from || undefined, to: to || undefined, limit: 1000 } });
      setRecords(data.records);
    } catch (e) { setError(errorText(e, "Unable to load records.")); } finally { setLoading(false); }
  }, [section, dq, owner, from, to]);
  useEffect(() => { load(); }, [load]);
  useEffect(() => { setPage(1); }, [dq, owner, from, to]);
  useEffect(() => { api.get("/admin/users", { params: { limit: 500, sort: "name", dir: "asc" } }).then((r) => setMembers(r.data.users)).catch(() => {}); }, []);

  const stats = useMemo(() => {
    const weekAgo = Date.now() - 7 * 864e5;
    return { total: records.length, week: records.filter((r) => new Date(r.createdAt) >= weekAgo).length, people: new Set(records.map((r) => r.owner?._id)).size };
  }, [records]);
  const pages = Math.max(Math.ceil(records.length / PAGE), 1);
  const shown = records.slice((page - 1) * PAGE, page * PAGE);

  const fmtCell = (r, k) => {
    const f = field(k), v = r.details?.[k];
    if (v === undefined || v === null || v === "") return <span className="muted">—</span>;
    if (f?.type === "date") return fmtDate(v);
    if (f?.type === "textarea") return <div className="adm-trunc" title={String(v)}>{String(v).replace(/\n/g, " · ")}</div>;
    if (k === "progress") return <Badge tone={Number(v) >= 100 ? "ok" : "info"} plain>{v}%</Badge>;
    return `${v}${f?.u ? ` ${f.u}` : ""}`;
  };

  function openCreate() { setEditId(null); setForm(blank()); setFormError(""); }
  function openEdit(r) {
    setEditId(r._id); setFormError("");
    setForm({ title: r.title, date: r.date ? new Date(r.date).toISOString().slice(0, 10) : today(), owner: r.owner?.role === "admin" ? "" : r.owner?._id || "", details: { ...(r.details || {}) } });
  }
  const setDetail = (k, v) => setForm((f) => ({ ...f, details: { ...f.details, [k]: v } }));

  async function save(e) {
    e.preventDefault(); setSaving(true); setFormError("");
    if (!cfg.shared && !form.owner) { setFormError("Choose the member this record belongs to."); setSaving(false); return; }
    try {
      const body = { title: form.title, date: form.date, details: form.details, ...(form.owner ? { owner: form.owner } : {}) };
      if (editId) await api.patch(`/fitness/${section}/${editId}`, body); else await api.post(`/fitness/${section}`, body);
      toast(editId ? "Record updated" : "Record added"); setForm(null); load();
    } catch (err) { setFormError(errorText(err, "Could not save record.")); } finally { setSaving(false); }
  }
  async function remove(r) {
    if (!(await confirm({ title: "Delete record?", message: `“${r.title}” will be permanently removed.`, confirmText: "Delete", danger: true }))) return;
    try { await api.delete(`/fitness/${section}/${r._id}`); toast("Record deleted"); setRecords((p) => p.filter((x) => x._id !== r._id)); } catch (e) { toast(errorText(e), "bad"); }
  }
  const exportCsv = () => downloadReport(section, { from: from || undefined, to: to || undefined }).catch((e) => toast(errorText(e, "Export failed."), "bad"));
  const filtered = q || owner || from || to;

  return <>
    <PageHeader title={cfg.title} subtitle={cfg.desc}>
      <button className="adm-btn" onClick={exportCsv}><Icon name="download" size={15} />Export CSV</button>
      <button className="adm-btn primary" onClick={openCreate}><Icon name="plus" size={15} />Add {cfg.title.toLowerCase().replace(/s$/, "")}</button>
    </PageHeader>
    {error && <Alert>{error}</Alert>}

    <div className="adm-stats">
      <div className="adm-card adm-stat"><small>{filtered ? "Matching records" : "Total records"}</small><strong>{stats.total}</strong></div>
      <div className="adm-card adm-stat"><small>Added this week</small><strong>{stats.week}</strong></div>
      <div className="adm-card adm-stat"><small>Contributors</small><strong>{stats.people}</strong></div>
    </div>

    <section className="adm-card">
      <div className="adm-toolbar">
        <div className="adm-search"><Icon name="search" size={16} /><input className="adm-input" placeholder={`Search ${cfg.title.toLowerCase()}…`} value={q} onChange={(e) => setQ(e.target.value)} aria-label="Search records" /></div>
        <select className="adm-select" value={owner} onChange={(e) => setOwner(e.target.value)} aria-label="Filter by member"><option value="">All members</option>{members.map((m) => <option key={m.id} value={m.id}>{m.name}{m.role === "admin" ? " (admin)" : ""}</option>)}</select>
        <input className="adm-input" type="date" value={from} max={to || undefined} onChange={(e) => setFrom(e.target.value)} aria-label="From date" title="From date" />
        <input className="adm-input" type="date" value={to} min={from || undefined} onChange={(e) => setTo(e.target.value)} aria-label="To date" title="To date" />
        {filtered && <button className="adm-btn" onClick={() => { setQ(""); setOwner(""); setFrom(""); setTo(""); }}>Clear</button>}
      </div>
      {loading ? <TableSkeleton /> : records.length === 0 ? <Empty icon={cfg.icon} title={filtered ? "No matching records" : `No ${cfg.title.toLowerCase()} yet`}>{filtered ? "Try adjusting your filters." : "Add the first one using the button above."}</Empty> : <div className="adm-table-wrap"><table className="adm-table">
        <thead><tr><th>Date</th><th>{cfg.titleLabel}</th><th>Member</th>{cfg.cols.map((k) => <th key={k}>{field(k)?.l}</th>)}<th style={{ textAlign: "right" }}>Actions</th></tr></thead>
        <tbody>{shown.map((r) => <tr key={r._id}>
          <td className="muted" style={{ whiteSpace: "nowrap" }}>{fmtDate(r.date || r.createdAt)}</td>
          <td><strong style={{ fontWeight: 600 }}>{r.title}</strong></td>
          <td>{r.owner?.role === "admin" ? <Badge tone="violet" plain>Shared library</Badge> : r.owner ? <Person user={r.owner} size={28} /> : <span className="muted">Deleted user</span>}</td>
          {cfg.cols.map((k) => <td key={k} className="num">{fmtCell(r, k)}</td>)}
          <td><div className="row-actions"><button className="adm-btn sm icon" title="Edit" aria-label={`Edit ${r.title}`} onClick={() => openEdit(r)}><Icon name="edit" size={15} /></button><button className="adm-btn sm icon danger" title="Delete" aria-label={`Delete ${r.title}`} onClick={() => remove(r)}><Icon name="trash" size={15} /></button></div></td>
        </tr>)}</tbody></table></div>}
      <Pager page={page} pages={pages} total={records.length} size={PAGE} onPage={setPage} label="records" />
    </section>

    <Modal open={!!form} size="lg" title={`${editId ? "Edit" : "Add"} ${cfg.title.toLowerCase().replace(/s$/, "")}`} onClose={() => setForm(null)}
      footer={<><button className="adm-btn" type="button" onClick={() => setForm(null)}>Cancel</button><button className="adm-btn primary" form="record-form" disabled={saving}>{saving ? "Saving…" : editId ? "Save changes" : "Add record"}</button></>}>
      {form && <form id="record-form" className="adm-form" onSubmit={save}>
        {formError && <div className="adm-field full"><Alert>{formError}</Alert></div>}
        <label className="adm-field">{cfg.titleLabel}<input className="adm-input" required maxLength={120} value={form.title} onChange={(e) => setForm((f) => ({ ...f, title: e.target.value }))} /></label>
        <label className="adm-field">Date<input className="adm-input" type="date" value={form.date} onChange={(e) => setForm((f) => ({ ...f, date: e.target.value }))} /></label>
        <label className="adm-field full">{cfg.shared ? "Visibility" : "Member"}
          <select className="adm-select" value={form.owner} onChange={(e) => setForm((f) => ({ ...f, owner: e.target.value }))}>
            {cfg.shared ? <option value="">Shared library — visible to all members</option> : <option value="">Select a member…</option>}
            {members.filter((m) => m.role === "client").map((m) => <option key={m.id} value={m.id}>{m.name} — {m.email}</option>)}
          </select></label>
        {cfg.fields.map((f) => {
          const value = form.details[f.k] ?? "";
          return <label key={f.k} className={`adm-field${f.full ? " full" : ""}`}>{f.l}{f.u ? ` (${f.u})` : ""}
            {f.type === "select" ? <select className="adm-select" value={value} onChange={(e) => setDetail(f.k, e.target.value)}><option value="">—</option>{[...new Set([...(f.options || []), ...(value ? [value] : [])])].map((o) => <option key={o}>{o}</option>)}</select>
              : f.type === "textarea" ? <textarea className="adm-textarea" value={value} onChange={(e) => setDetail(f.k, e.target.value)} />
              : <input className="adm-input" type={f.type || "text"} step={f.step} min={f.min ?? (f.type === "number" ? 0 : undefined)} max={f.max} value={value} onChange={(e) => setDetail(f.k, f.type === "number" && e.target.value !== "" ? Number(e.target.value) : e.target.value)} />}
            {f.hint && <small>{f.hint}</small>}</label>;
        })}
      </form>}
    </Modal>
  </>;
}
