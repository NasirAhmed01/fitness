import { useState } from "react";
import { Icon, PageHeader, useAdminUI } from "./ui";
import { downloadReport, errorText, printReport } from "./utils";

const REPORTS = [
  ["users", "User directory", "users", "tone-accent", "Every account with role, status, profile data and last login."],
  ["workout", "Workouts", "workout", "tone-info", "Workout plans with duration, sets and reps."],
  ["exercise", "Exercise library", "dumbbell", "tone-warn", "The exercise catalogue with category and difficulty."],
  ["weight", "Weight history", "gauge", "tone-ok", "Body-weight entries for all members."],
  ["measurement", "Body measurements", "ruler", "tone-violet", "Waist, chest, arm and hip measurements."],
  ["performance", "Performance", "activity", "tone-warn", "Lifting volume, durations and personal records."],
  ["food", "Nutrition", "utensils", "tone-bad", "Food logs with calories and macronutrients."],
  ["goal", "Goals", "target", "tone-ok", "Member targets, deadlines and progress."],
  ["tickets", "Support tickets", "lifebuoy", "tone-info", "Tickets with category, priority, status and reply counts."]
];

export default function Reports() {
  const { toast } = useAdminUI();
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [busy, setBusy] = useState("");
  const params = { from: from || undefined, to: to || undefined };

  async function run(kind, id) {
    setBusy(`${kind}-${id}`);
    try { await (kind === "csv" ? downloadReport(id, params) : printReport(id, params)); toast(kind === "csv" ? "CSV downloaded" : "Report opened — choose “Save as PDF” in the print dialog"); }
    catch (e) { toast(errorText(e, "Could not create the report."), "bad"); } finally { setBusy(""); }
  }

  return <>
    <PageHeader title="Reports & export" subtitle="Generate fitness, nutrition and user reports as CSV spreadsheets or printable PDFs." />
    <section className="adm-card"><div className="adm-toolbar" style={{ borderBottom: 0 }}>
      <strong style={{ marginRight: 6 }}>Date range</strong>
      <label className="adm-field" style={{ flexDirection: "row", alignItems: "center", gap: 8 }}>From<input className="adm-input" type="date" value={from} max={to || undefined} onChange={(e) => setFrom(e.target.value)} /></label>
      <label className="adm-field" style={{ flexDirection: "row", alignItems: "center", gap: 8 }}>To<input className="adm-input" type="date" value={to} min={from || undefined} onChange={(e) => setTo(e.target.value)} /></label>
      {(from || to) && <button className="adm-btn" onClick={() => { setFrom(""); setTo(""); }}>Clear</button>}
      <span style={{ color: "var(--muted)", fontSize: 12.5 }}>Applies to dated records. The user directory always lists every account.</span>
    </div></section>
    <div className="adm-grid g3">{REPORTS.map(([id, title, icon, tone, text]) => <section className="adm-card adm-report" key={id}>
      <span className={`adm-kpi-ico ${tone}`}><Icon name={icon} size={21} /></span>
      <div><h2 style={{ font: "700 16px Manrope" }}>{title}</h2><p style={{ marginTop: 4 }}>{text}</p></div>
      <div className="row">
        <button className="adm-btn" disabled={!!busy} onClick={() => run("csv", id)}><Icon name="download" size={15} />{busy === `csv-${id}` ? "Preparing…" : "CSV"}</button>
        <button className="adm-btn" disabled={!!busy} onClick={() => run("pdf", id)}><Icon name="printer" size={15} />{busy === `pdf-${id}` ? "Preparing…" : "PDF"}</button>
      </div></section>)}</div>
  </>;
}
