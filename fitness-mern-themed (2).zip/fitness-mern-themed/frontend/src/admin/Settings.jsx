import { useRef, useState } from "react";
import { useOutletContext } from "react-router-dom";
import api from "../api";
import { useAuth } from "../auth/AuthContext";
import { Alert, Avatar, Icon, PageHeader, Switch, useAdminUI } from "./ui";
import { errorText } from "./utils";

export default function Settings() {
  const { user, setUser } = useAuth();
  const { theme, setTheme } = useOutletContext();
  const { toast } = useAdminUI();
  const [tab, setTab] = useState("profile");
  const [form, setForm] = useState({ name: user.name, phone: user.phone || "", profileImage: user.profileImage || "" });
  const [prefs, setPrefs] = useState(user.preferences);
  const [pw, setPw] = useState({ currentPassword: "", newPassword: "", confirm: "" });
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);
  const fileRef = useRef(null);

  function pickImage(e) {
    const f = e.target.files?.[0]; if (!f) return;
    if (!f.type.startsWith("image/") || f.size > 2 * 1024 * 1024) { setErr("Choose an image file smaller than 2 MB."); return; }
    const r = new FileReader(); r.onload = () => { setErr(""); setForm((p) => ({ ...p, profileImage: r.result })); }; r.readAsDataURL(f);
  }
  async function saveProfile(e) {
    e.preventDefault(); setBusy(true); setErr("");
    try { const { data } = await api.patch("/users/me", form); setUser(data.user); toast("Profile saved"); } catch (x) { setErr(errorText(x, "Could not save profile.")); } finally { setBusy(false); }
  }
  async function savePrefs(next) {
    setPrefs(next);
    try { const { data } = await api.patch("/users/me", { preferences: next }); setUser(data.user); toast("Preferences saved"); } catch (x) { toast(errorText(x), "bad"); }
  }
  async function changePassword(e) {
    e.preventDefault(); setErr("");
    if (pw.newPassword !== pw.confirm) { setErr("New password and confirmation do not match."); return; }
    setBusy(true);
    try { await api.patch("/users/me/password", { currentPassword: pw.currentPassword, newPassword: pw.newPassword }); setPw({ currentPassword: "", newPassword: "", confirm: "" }); toast("Password changed"); } catch (x) { setErr(errorText(x, "Could not change password.")); } finally { setBusy(false); }
  }

  return <>
    <PageHeader title="Settings" subtitle="Manage your administrator profile, appearance and security." />
    <section className="adm-card" style={{ maxWidth: 820 }}>
      <div className="adm-tabs">{[["profile", "Profile", "users"], ["preferences", "Preferences", "settings"], ["security", "Security", "key"]].map(([k, l, i]) => <button key={k} className={tab === k ? "on" : ""} onClick={() => { setTab(k); setErr(""); }}><Icon name={i} size={15} />{l}</button>)}</div>
      <div className="adm-card-b" style={{ paddingTop: 22 }}>
        {err && <div style={{ marginBottom: 16 }}><Alert>{err}</Alert></div>}

        {tab === "profile" && <form onSubmit={saveProfile}>
          <div className="adm-profile-top"><Avatar user={form} size={76} />
            <div><button type="button" className="adm-btn" onClick={() => fileRef.current?.click()}>Upload photo</button>{form.profileImage && <button type="button" className="adm-btn" style={{ marginLeft: 8 }} onClick={() => setForm((p) => ({ ...p, profileImage: "" }))}>Remove</button>}
              <input hidden ref={fileRef} type="file" accept="image/*" onChange={pickImage} /><p style={{ color: "var(--muted)", fontSize: 12, marginTop: 6 }}>PNG or JPG, up to 2 MB.</p></div></div>
          <div className="adm-form">
            <label className="adm-field">Full name<input className="adm-input" required minLength={2} value={form.name} onChange={(e) => setForm((p) => ({ ...p, name: e.target.value }))} /></label>
            <label className="adm-field">Phone<input className="adm-input" value={form.phone} onChange={(e) => setForm((p) => ({ ...p, phone: e.target.value }))} /></label>
            <label className="adm-field full">Email address<input className="adm-input" value={user.email} disabled /><small>Your login email cannot be changed here.</small></label>
          </div>
          <div style={{ marginTop: 20 }}><button className="adm-btn primary" disabled={busy}>{busy ? "Saving…" : "Save profile"}</button></div>
        </form>}

        {tab === "preferences" && <div>
          <div className="adm-setrow"><div><strong>Theme</strong><small>Choose how the admin console looks.</small></div>
            <div className="adm-seg"><button className={theme === "light" ? "on" : ""} onClick={() => setTheme("light")}><Icon name="sun" size={15} />Light</button><button className={theme === "dark" ? "on" : ""} onClick={() => setTheme("dark")}><Icon name="moon" size={15} />Dark</button></div></div>
          <div className="adm-setrow"><div><strong>Units of measurement</strong><small>Used for your own views of weight and height.</small></div>
            <div className="adm-seg"><button className={prefs.units === "metric" ? "on" : ""} onClick={() => savePrefs({ ...prefs, units: "metric" })}>Metric</button><button className={prefs.units === "imperial" ? "on" : ""} onClick={() => savePrefs({ ...prefs, units: "imperial" })}>Imperial</button></div></div>
          <div className="adm-setrow"><div><strong>Email notifications</strong><small>Receive a summary when new support tickets arrive.</small></div><Switch label="Email notifications" on={prefs.emailNotifications} onChange={(v) => savePrefs({ ...prefs, emailNotifications: v })} /></div>
          <div className="adm-setrow"><div><strong>Workout reminders</strong><small>Show reminder notifications in your own inbox.</small></div><Switch label="Workout reminders" on={prefs.workoutReminders} onChange={(v) => savePrefs({ ...prefs, workoutReminders: v })} /></div>
        </div>}

        {tab === "security" && <form onSubmit={changePassword} style={{ maxWidth: 420, display: "flex", flexDirection: "column", gap: 14 }}>
          <label className="adm-field">Current password<input className="adm-input" type="password" required autoComplete="current-password" value={pw.currentPassword} onChange={(e) => setPw((p) => ({ ...p, currentPassword: e.target.value }))} /></label>
          <label className="adm-field">New password<input className="adm-input" type="password" required minLength={8} autoComplete="new-password" value={pw.newPassword} onChange={(e) => setPw((p) => ({ ...p, newPassword: e.target.value }))} /><small>At least 8 characters.</small></label>
          <label className="adm-field">Confirm new password<input className="adm-input" type="password" required minLength={8} autoComplete="new-password" value={pw.confirm} onChange={(e) => setPw((p) => ({ ...p, confirm: e.target.value }))} /></label>
          <div><button className="adm-btn primary" disabled={busy}>{busy ? "Updating…" : "Change password"}</button></div>
        </form>}
      </div>
    </section>
  </>;
}
