import { useCallback, useEffect, useMemo, useState } from "react";
import api from "../api";
import { Alert, Badge, Empty, Icon, PageHeader, Person, TableSkeleton, useAdminUI, useDebounce } from "./ui";
import { errorText, timeAgo } from "./utils";

const STATUS = { open: ["Open", "warn"], in_progress: ["In progress", "info"], resolved: ["Resolved", "ok"] };
const PRIORITY = { low: ["Low", "muted"], medium: ["Medium", "info"], high: ["High", "bad"] };

export default function Support() {
  const { toast, confirm } = useAdminUI();
  const [tickets, setTickets] = useState([]);
  const [counts, setCounts] = useState({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [status, setStatus] = useState("");
  const [priority, setPriority] = useState("");
  const [q, setQ] = useState("");
  const [selected, setSelected] = useState(null);
  const [reply, setReply] = useState("");
  const [busy, setBusy] = useState(false);
  const dq = useDebounce(q);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const { data } = await api.get("/admin/tickets", { params: { status: status || undefined, priority: priority || undefined, q: dq || undefined } });
      setTickets(data.tickets); setCounts(data.counts); setError("");
    } catch (e) { setError(errorText(e, "Unable to load tickets.")); } finally { setLoading(false); }
  }, [status, priority, dq]);
  useEffect(() => { load(); }, [load]);

  const ticket = useMemo(() => tickets.find((t) => t._id === selected) || null, [tickets, selected]);
  const total = (counts.open || 0) + (counts.in_progress || 0) + (counts.resolved || 0);

  async function update(patch, okMessage) {
    setBusy(true);
    try {
      const { data } = await api.patch(`/admin/tickets/${ticket._id}`, patch);
      setTickets((list) => list.map((t) => (t._id === data.ticket._id ? data.ticket : t)));
      api.get("/admin/tickets").then((r) => setCounts(r.data.counts)).catch(() => {});
      if (patch.reply) setReply("");
      toast(okMessage);
    } catch (e) { toast(errorText(e), "bad"); } finally { setBusy(false); }
  }
  async function remove() {
    if (!(await confirm({ title: "Delete ticket?", message: "The ticket and its conversation will be permanently deleted.", confirmText: "Delete", danger: true }))) return;
    try { await api.delete(`/admin/tickets/${ticket._id}`); toast("Ticket deleted"); setSelected(null); load(); } catch (e) { toast(errorText(e), "bad"); }
  }

  const tabs = [["", "All", total], ["open", "Open", counts.open || 0], ["in_progress", "In progress", counts.in_progress || 0], ["resolved", "Resolved", counts.resolved || 0]];

  return <>
    <PageHeader title="Support" subtitle="Answer member questions, handle issue reports and review feedback." />
    {error && <Alert>{error}</Alert>}
    <section className="adm-card" style={{ overflow: "hidden" }}>
      <div className="adm-tabs" role="tablist">{tabs.map(([k, l, c]) => <button key={k} role="tab" aria-selected={status === k} className={status === k ? "on" : ""} onClick={() => setStatus(k)}>{l}<span className="c">{c}</span></button>)}</div>
      <div className="adm-split">
        <aside>
          <div className="adm-toolbar"><div className="adm-search" style={{ minWidth: 120 }}><Icon name="search" size={16} /><input className="adm-input" placeholder="Search tickets…" value={q} onChange={(e) => setQ(e.target.value)} aria-label="Search tickets" /></div>
            <select className="adm-select" style={{ minWidth: 0 }} value={priority} onChange={(e) => setPriority(e.target.value)} aria-label="Filter by priority"><option value="">Any priority</option><option value="high">High</option><option value="medium">Medium</option><option value="low">Low</option></select></div>
          <div className="adm-ticket-list">{loading ? <TableSkeleton rows={5} /> : tickets.length === 0 ? <Empty icon="lifebuoy" title="No tickets">Nothing matches this view.</Empty> : tickets.map((t) => <button key={t._id} className={`adm-ticket${t._id === selected ? " on" : ""}`} onClick={() => { setSelected(t._id); setReply(""); }}>
            <div className="row"><strong style={{ overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{t.subject}</strong><Badge tone={STATUS[t.status][1]} plain>{STATUS[t.status][0]}</Badge></div>
            <small>{t.owner?.name || "Deleted user"} · {t.category} · {timeAgo(t.updatedAt)}</small>
            <div><Badge tone={PRIORITY[t.priority][1]}>{PRIORITY[t.priority][0]}</Badge></div></button>)}</div>
        </aside>

        {!ticket ? <div style={{ display: "grid", placeItems: "center" }}><Empty icon="message" title="Select a ticket">Choose a conversation on the left to read and reply.</Empty></div> :
          <div className="adm-thread">
            <div style={{ display: "flex", justifyContent: "space-between", gap: 12, flexWrap: "wrap", alignItems: "flex-start" }}>
              <div style={{ minWidth: 0 }}><h2 style={{ font: "700 18px Manrope", wordBreak: "break-word" }}>{ticket.subject}</h2><div style={{ marginTop: 8 }}><Person user={ticket.owner} size={30} sub={`${ticket.owner?.email || ""} · opened ${timeAgo(ticket.createdAt)}`} /></div></div>
              <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
                <select className="adm-select" style={{ width: "auto" }} value={ticket.status} disabled={busy} onChange={(e) => update({ status: e.target.value }, "Status updated")} aria-label="Ticket status">{Object.entries(STATUS).map(([k, v]) => <option key={k} value={k}>{v[0]}</option>)}</select>
                <select className="adm-select" style={{ width: "auto" }} value={ticket.priority} disabled={busy} onChange={(e) => update({ priority: e.target.value }, "Priority updated")} aria-label="Ticket priority">{Object.entries(PRIORITY).map(([k, v]) => <option key={k} value={k}>{v[0]}</option>)}</select>
                <button className="adm-btn danger icon" aria-label="Delete ticket" onClick={remove}><Icon name="trash" size={15} /></button></div>
            </div>
            <div className="adm-msg"><small>{ticket.owner?.name} · {ticket.category}</small>{ticket.message}</div>
            {ticket.replies.map((r) => <div key={r._id} className={`adm-msg${r.role === "admin" ? " admin" : ""}`}><small>{r.authorName || r.role} · {timeAgo(r.createdAt)}</small>{r.message}</div>)}
            <form style={{ marginTop: "auto", display: "flex", flexDirection: "column", gap: 10 }} onSubmit={(e) => { e.preventDefault(); if (reply.trim()) update({ reply }, "Reply sent to member"); }}>
              <textarea className="adm-textarea" placeholder="Write a reply — the member is notified in-app…" maxLength={2000} value={reply} onChange={(e) => setReply(e.target.value)} />
              <div style={{ display: "flex", justifyContent: "flex-end", gap: 8 }}>
                {ticket.status !== "resolved" && <button type="button" className="adm-btn" disabled={busy} onClick={() => update({ status: "resolved", reply: reply.trim() || undefined }, "Ticket resolved")}><Icon name="check" size={15} />Resolve</button>}
                <button className="adm-btn primary" disabled={busy || !reply.trim()}><Icon name="send" size={15} />Send reply</button></div>
            </form>
          </div>}
      </div>
    </section>
  </>;
}
