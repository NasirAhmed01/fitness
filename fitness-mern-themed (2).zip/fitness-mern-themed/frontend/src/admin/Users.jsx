import { useCallback, useEffect, useState } from "react";
import api from "../api";
import { useAuth } from "../auth/AuthContext";
import { Alert, Avatar, Badge, Empty, Icon, Modal, PageHeader, Pager, Person, TableSkeleton, useAdminUI, useDebounce } from "./ui";
import { GOALS, downloadReport, errorText, fmtDate, timeAgo } from "./utils";

const BLANK = { name: "", email: "", password: "", role: "client", status: "active", phone: "", age: "", heightCm: "", currentWeight: "", fitnessGoal: "" };
const PAGE = 10;
const TYPE_LABEL = { exercise: "Exercises", workout: "Workouts", weight: "Weight", measurement: "Measurements", performance: "Performance", food: "Food logs", goal: "Goals", notification: "Notifications" };

export default function Users() {
  const { user: me } = useAuth();
  const { toast, confirm } = useAdminUI();
  const [rows, setRows] = useState([]);
  const [meta, setMeta] = useState({ total: 0, pages: 1 });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [q, setQ] = useState("");
  const [role, setRole] = useState("");
  const [status, setStatus] = useState("");
  const [sort, setSort] = useState({ key: "createdAt", dir: "desc" });
  const [page, setPage] = useState(1);
  const [form, setForm] = useState(null);       // null = closed, object = create/edit
  const [editId, setEditId] = useState(null);
  const [saving, setSaving] = useState(false);
  const [formError, setFormError] = useState("");
  const [detail, setDetail] = useState(null);
  const dq = useDebounce(q);

  const load = useCallback(async () => {
    setLoading(true); setError("");
    try {
      const { data } = await api.get("/admin/users", { params: { q: dq, role, status, page, limit: PAGE, sort: sort.key, dir: sort.dir } });
      setRows(data.users); setMeta({ total: data.total, pages: data.pages });
      if (page > data.pages) setPage(data.pages);
    } catch (e) { setError(errorText(e, "Unable to load users.")); } finally { setLoading(false); }
  }, [dq, role, status, page, sort]);
  useEffect(() => { load(); }, [load]);
  useEffect(() => { setPage(1); }, [dq, role, status]);

  const toggleSort = (key) => setSort((s) => ({ key, dir: s.key === key && s.dir === "asc" ? "desc" : "asc" }));
  const arrow = (key) => (sort.key === key ? (sort.dir === "asc" ? " ↑" : " ↓") : "");
  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));

  function openCreate() { setEditId(null); setForm({ ...BLANK }); setFormError(""); }
  function openEdit(u) { setEditId(u.id); setForm({ ...BLANK, ...u, password: "" }); setFormError(""); }

  async function save(e) {
    e.preventDefault(); setSaving(true); setFormError("");
    try {
      if (editId) {
        const body = { ...form }; delete body.id; delete body.createdAt; delete body.profileImage; delete body.records; delete body.lastLoginAt; delete body.preferences;
        if (!body.password) delete body.password;
        await api.patch(`/admin/users/${editId}`, body); toast("User updated");
      } else { await api.post("/admin/users", form); toast("User created"); }
      setForm(null); load();
    } catch (err) { setFormError(errorText(err, "Could not save user.")); } finally { setSaving(false); }
  }
  async function toggleStatus(u) {
    const next = u.status === "suspended" ? "active" : "suspended";
    if (next === "suspended" && !(await confirm({ title: "Suspend account?", message: `${u.name} will be signed out and unable to log in until reactivated.`, confirmText: "Suspend", danger: true }))) return;
    try { await api.patch(`/admin/users/${u.id}`, { status: next }); toast(next === "active" ? "Account reactivated" : "Account suspended"); load(); } catch (e) { toast(errorText(e), "bad"); }
  }
  async function remove(u) {
    if (!(await confirm({ title: "Delete user?", message: `This permanently deletes ${u.name} together with all their fitness records and support tickets.`, confirmText: "Delete user", danger: true }))) return;
    try { await api.delete(`/admin/users/${u.id}`); toast("User deleted"); load(); } catch (e) { toast(errorText(e), "bad"); }
  }
  async function view(u) {
    setDetail({ user: u, loading: true });
    try { const { data } = await api.get(`/admin/users/${u.id}`); setDetail({ ...data, loading: false }); } catch (e) { setDetail(null); toast(errorText(e), "bad"); }
  }
  const exportCsv = () => downloadReport("users", { q: dq, role, status }).catch((e) => toast(errorText(e, "Export failed."), "bad"));
  const clear = () => { setQ(""); setRole(""); setStatus(""); };

  return <>
    <PageHeader title="Users" subtitle="Create accounts, assign roles, suspend access and review each member's activity.">
      <button className="adm-btn" onClick={exportCsv}><Icon name="download" size={15} />Export CSV</button>
      <button className="adm-btn primary" onClick={openCreate}><Icon name="plus" size={15} />Add user</button>
    </PageHeader>
    {error && <Alert>{error}</Alert>}

    <section className="adm-card">
      <div className="adm-toolbar">
        <div className="adm-search"><Icon name="search" size={16} /><input className="adm-input" placeholder="Search name, email or phone…" value={q} onChange={(e) => setQ(e.target.value)} aria-label="Search users" /></div>
        <select className="adm-select" value={role} onChange={(e) => setRole(e.target.value)} aria-label="Filter by role"><option value="">All roles</option><option value="client">Clients</option><option value="admin">Admins</option></select>
        <select className="adm-select" value={status} onChange={(e) => setStatus(e.target.value)} aria-label="Filter by status"><option value="">All statuses</option><option value="active">Active</option><option value="suspended">Suspended</option></select>
        {(q || role || status) && <button className="adm-btn" onClick={clear}>Clear</button>}
      </div>
      {loading ? <TableSkeleton /> : rows.length === 0 ? <Empty icon="users" title="No users found">Try changing the search or filters.</Empty> : <div className="adm-table-wrap"><table className="adm-table">
        <thead><tr><th className="sort" onClick={() => toggleSort("name")}>User{arrow("name")}</th><th>Role</th><th>Status</th><th>Records</th><th className="sort" onClick={() => toggleSort("createdAt")}>Joined{arrow("createdAt")}</th><th className="sort" onClick={() => toggleSort("lastLoginAt")}>Last login{arrow("lastLoginAt")}</th><th style={{ textAlign: "right" }}>Actions</th></tr></thead>
        <tbody>{rows.map((u) => { const self = u.id === me.id; return <tr key={u.id}>
          <td><Person user={u} /></td>
          <td><Badge tone={u.role === "admin" ? "violet" : "info"}>{u.role}</Badge></td>
          <td><Badge tone={u.status === "suspended" ? "bad" : "ok"}>{u.status === "suspended" ? "Suspended" : "Active"}</Badge></td>
          <td className="num">{u.records}</td>
          <td className="muted">{fmtDate(u.createdAt)}</td>
          <td className="muted">{timeAgo(u.lastLoginAt)}</td>
          <td><div className="row-actions">
            <button className="adm-btn sm icon" title="View details" aria-label={`View ${u.name}`} onClick={() => view(u)}><Icon name="eye" size={15} /></button>
            <button className="adm-btn sm icon" title="Edit" aria-label={`Edit ${u.name}`} onClick={() => openEdit(u)}><Icon name="edit" size={15} /></button>
            <button className="adm-btn sm icon" title={u.status === "suspended" ? "Reactivate" : "Suspend"} aria-label="Toggle suspension" disabled={self} onClick={() => toggleStatus(u)}><Icon name={u.status === "suspended" ? "check" : "ban"} size={15} /></button>
            <button className="adm-btn sm icon danger" title="Delete" aria-label={`Delete ${u.name}`} disabled={self} onClick={() => remove(u)}><Icon name="trash" size={15} /></button>
          </div></td></tr>; })}</tbody></table></div>}
      <Pager page={page} pages={meta.pages} total={meta.total} size={PAGE} onPage={setPage} label="users" />
    </section>

    <Modal open={!!form} size="lg" title={editId ? "Edit user" : "Add user"} onClose={() => setForm(null)}
      footer={<><button className="adm-btn" type="button" onClick={() => setForm(null)}>Cancel</button><button className="adm-btn primary" form="user-form" disabled={saving}>{saving ? "Saving…" : editId ? "Save changes" : "Create user"}</button></>}>
      {form && <form id="user-form" className="adm-form" onSubmit={save}>
        {formError && <div className="adm-field full"><Alert>{formError}</Alert></div>}
        <label className="adm-field">Full name<input className="adm-input" required minLength={2} value={form.name} onChange={(e) => set("name", e.target.value)} /></label>
        <label className="adm-field">Email<input className="adm-input" type="email" required value={form.email} onChange={(e) => set("email", e.target.value)} /></label>
        <label className="adm-field">{editId ? "Reset password" : "Password"}<input className="adm-input" type="password" minLength={8} required={!editId} autoComplete="new-password" placeholder={editId ? "Leave blank to keep current" : "At least 8 characters"} value={form.password} onChange={(e) => set("password", e.target.value)} /></label>
        <label className="adm-field">Phone<input className="adm-input" value={form.phone} onChange={(e) => set("phone", e.target.value)} /></label>
        <label className="adm-field">Role<select className="adm-select" value={form.role} onChange={(e) => set("role", e.target.value)} disabled={editId === me.id}><option value="client">Client</option><option value="admin">Admin</option></select></label>
        <label className="adm-field">Status<select className="adm-select" value={form.status} onChange={(e) => set("status", e.target.value)} disabled={editId === me.id}><option value="active">Active</option><option value="suspended">Suspended</option></select></label>
        <label className="adm-field">Age<input className="adm-input" type="number" min="13" max="120" value={form.age ?? ""} onChange={(e) => set("age", e.target.value)} /></label>
        <label className="adm-field">Fitness goal<select className="adm-select" value={form.fitnessGoal || ""} onChange={(e) => set("fitnessGoal", e.target.value)}><option value="">Not set</option><option value="muscle_gain">Muscle gain</option><option value="weight_loss">Weight loss</option><option value="maintenance">Maintenance</option><option value="general_fitness">General fitness</option></select></label>
        <label className="adm-field">Height (cm)<input className="adm-input" type="number" min="50" max="260" value={form.heightCm ?? ""} onChange={(e) => set("heightCm", e.target.value)} /></label>
        <label className="adm-field">Current weight (kg)<input className="adm-input" type="number" min="20" max="500" step="0.1" value={form.currentWeight ?? ""} onChange={(e) => set("currentWeight", e.target.value)} /></label>
      </form>}
    </Modal>

    <Modal open={!!detail} size="lg" title="Member profile" onClose={() => setDetail(null)}
      footer={detail && !detail.loading && <><button className="adm-btn" onClick={() => { const u = detail.user; setDetail(null); openEdit(u); }}><Icon name="edit" size={15} />Edit</button><button className="adm-btn primary" onClick={() => setDetail(null)}>Close</button></>}>
      {detail && (detail.loading ? <TableSkeleton rows={4} /> : <>
        <div className="adm-profile-top"><Avatar user={detail.user} size={64} /><div><h2 style={{ font: "800 20px Manrope" }}>{detail.user.name}</h2><p style={{ color: "var(--muted)" }}>{detail.user.email}</p>
          <div style={{ display: "flex", gap: 8, marginTop: 8 }}><Badge tone={detail.user.role === "admin" ? "violet" : "info"}>{detail.user.role}</Badge><Badge tone={detail.user.status === "suspended" ? "bad" : "ok"}>{detail.user.status === "suspended" ? "Suspended" : "Active"}</Badge></div></div></div>
        <div className="adm-kv">
          <div><small>Phone</small><b>{detail.user.phone || "—"}</b></div><div><small>Age</small><b>{detail.user.age || "—"}</b></div>
          <div><small>Height</small><b>{detail.user.heightCm ? `${detail.user.heightCm} cm` : "—"}</b></div><div><small>Weight</small><b>{detail.user.currentWeight ? `${detail.user.currentWeight} kg` : "—"}</b></div>
          <div><small>Goal</small><b>{GOALS[detail.user.fitnessGoal] || "—"}</b></div><div><small>Support tickets</small><b>{detail.tickets}</b></div>
          <div><small>Joined</small><b>{fmtDate(detail.user.createdAt)}</b></div><div><small>Last login</small><b>{timeAgo(detail.user.lastLoginAt)}</b></div>
        </div>
        <h3 style={{ font: "700 14px Manrope", margin: "20px 0 10px" }}>Tracked data</h3>
        <div className="adm-chips">{Object.keys(detail.counts).length ? Object.entries(detail.counts).map(([t, n]) => <span className="adm-chip" key={t}>{TYPE_LABEL[t] || t}<b>{n}</b></span>) : <span style={{ color: "var(--muted)" }}>No records yet.</span>}</div>
        {detail.recent.length > 0 && <><h3 style={{ font: "700 14px Manrope", margin: "20px 0 4px" }}>Latest entries</h3><div className="adm-feed">{detail.recent.map((r) => <div className="adm-feed-item" key={r.id}><div><strong>{r.title}</strong><small>{TYPE_LABEL[r.type]} · {fmtDate(r.date)}</small></div></div>)}</div></>}
      </>)}
    </Modal>
  </>;
}
