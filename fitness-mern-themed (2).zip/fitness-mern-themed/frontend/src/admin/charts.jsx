import { useId, useState } from "react";

const niceMax = (max) => Math.max(4, Math.ceil(max / 4) * 4);

export function AreaChart({ data, color = "var(--accent)", height = 230, unit = "" }) {
  const gid = useId().replace(/:/g, "");
  const [hover, setHover] = useState(null);
  const W = 640, H = height, L = 34, R = 12, T = 16, B = 28;
  const top = niceMax(Math.max(0, ...data.map((d) => d.value)));
  const x = (i) => L + (data.length < 2 ? 0 : (i * (W - L - R)) / (data.length - 1));
  const y = (v) => T + (H - T - B) * (1 - v / top);
  const line = data.map((d, i) => `${i ? "L" : "M"}${x(i).toFixed(1)},${y(d.value).toFixed(1)}`).join(" ");
  const area = `${line} L${x(data.length - 1)},${H - B} L${x(0)},${H - B} Z`;
  const step = Math.ceil(data.length / 7);
  const h = hover !== null ? data[hover] : null;
  return <svg className="adm-chart" viewBox={`0 0 ${W} ${H}`} role="img" aria-label="Line chart">
    <defs><linearGradient id={gid} x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor={color} stopOpacity=".35" /><stop offset="1" stopColor={color} stopOpacity="0" /></linearGradient></defs>
    {[0, 1, 2, 3, 4].map((k) => { const v = (top * k) / 4; return <g key={k}><line x1={L} x2={W - R} y1={y(v)} y2={y(v)} stroke="var(--line)" strokeDasharray={k ? "3 4" : ""} /><text x={L - 8} y={y(v) + 4} textAnchor="end">{v}</text></g>; })}
    <path d={area} fill={`url(#${gid})`} />
    <path d={line} fill="none" stroke={color} strokeWidth="2.6" strokeLinejoin="round" strokeLinecap="round" />
    {data.map((d, i) => i % step === 0 || i === data.length - 1 ? <text key={i} x={x(i)} y={H - 8} textAnchor="middle">{d.label}</text> : null)}
    {data.map((d, i) => <rect key={i} x={x(i) - (W - L - R) / data.length / 2} y={T} width={(W - L - R) / data.length} height={H - T - B} fill="transparent" onMouseEnter={() => setHover(i)} onMouseLeave={() => setHover(null)} onTouchStart={() => setHover(i)} />)}
    {h && <g>
      <line x1={x(hover)} x2={x(hover)} y1={T} y2={H - B} stroke={color} strokeOpacity=".4" />
      <circle cx={x(hover)} cy={y(h.value)} r="5" fill="var(--surface)" stroke={color} strokeWidth="3" />
      <g className="tip" transform={`translate(${Math.min(Math.max(x(hover) - 55, L), W - R - 110)},${Math.max(y(h.value) - 52, 0)})`}><rect width="110" height="40" rx="9" /><text x="55" y="16" textAnchor="middle" style={{ fill: "var(--muted)", fontWeight: 400 }}>{h.label}</text><text x="55" y="32" textAnchor="middle">{h.value}{unit}</text></g>
    </g>}
  </svg>;
}

export function BarChart({ data, color = "var(--accent)", height = 230 }) {
  const [hover, setHover] = useState(null);
  const W = 640, H = height, L = 34, R = 12, T = 16, B = 28;
  const top = niceMax(Math.max(0, ...data.map((d) => d.value)));
  const slot = (W - L - R) / data.length, bw = Math.min(46, slot * 0.58);
  const y = (v) => T + (H - T - B) * (1 - v / top);
  return <svg className="adm-chart" viewBox={`0 0 ${W} ${H}`} role="img" aria-label="Bar chart">
    {[0, 1, 2, 3, 4].map((k) => { const v = (top * k) / 4; return <g key={k}><line x1={L} x2={W - R} y1={y(v)} y2={y(v)} stroke="var(--line)" strokeDasharray={k ? "3 4" : ""} /><text x={L - 8} y={y(v) + 4} textAnchor="end">{v}</text></g>; })}
    {data.map((d, i) => { const cx = L + slot * i + slot / 2, bh = H - B - y(d.value);
      return <g key={i} onMouseEnter={() => setHover(i)} onMouseLeave={() => setHover(null)}>
        <rect x={cx - bw / 2} y={y(d.value)} width={bw} height={Math.max(bh, d.value ? 3 : 0)} rx="8" fill={color} opacity={hover === null || hover === i ? 1 : 0.45} />
        <text x={cx} y={y(d.value) - 7} textAnchor="middle" style={{ fill: "var(--text)", fontWeight: 700 }}>{d.value || ""}</text>
        <text x={cx} y={H - 8} textAnchor="middle">{d.label}</text></g>; })}
  </svg>;
}

export function Donut({ segments, size = 168, thickness = 20, center }) {
  const total = segments.reduce((s, x) => s + x.value, 0);
  const r = (size - thickness) / 2, c = 2 * Math.PI * r;
  let acc = 0;
  return <div className="adm-donut">
    <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} role="img" aria-label="Donut chart" style={{ flex: "none" }}>
      <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="var(--surface2)" strokeWidth={thickness} />
      {total > 0 && segments.map((s, i) => { const len = (s.value / total) * c, off = acc; acc += len;
        return s.value > 0 ? <circle key={i} cx={size / 2} cy={size / 2} r={r} fill="none" stroke={s.color} strokeWidth={thickness} strokeDasharray={`${Math.max(len - 3, 0)} ${c - Math.max(len - 3, 0)}`} strokeDashoffset={-off} transform={`rotate(-90 ${size / 2} ${size / 2})`} strokeLinecap="butt" /> : null; })}
      {center && <><text x="50%" y="49%" textAnchor="middle" style={{ fill: "var(--text)", fontSize: 26, fontWeight: 800, fontFamily: "Manrope" }}>{center.value}</text><text x="50%" y="49%" dy="19" textAnchor="middle" style={{ fill: "var(--muted)", fontSize: 11 }}>{center.label}</text></>}
    </svg>
    <div className="adm-legend">{segments.map((s) => <div key={s.label}><i style={{ background: s.color }} />{s.label}<b>{s.value}{s.suffix || ""}</b></div>)}</div>
  </div>;
}

export function BarList({ items }) {
  const max = Math.max(1, ...items.map((i) => i.value));
  return <div className="adm-barlist">{items.map((i) => <div className="adm-barlist-row" key={i.label}><span>{i.label}</span><div className="track"><div className="fill" style={{ width: `${(i.value / max) * 100}%`, background: i.color || "var(--accent)" }} /></div><b>{i.value}</b></div>)}</div>;
}
