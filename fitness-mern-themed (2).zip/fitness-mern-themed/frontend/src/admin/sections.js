// Field definitions for every tracker. Values are stored in the flexible `details` object of a FitnessRecord.
const num = (k, l, u, extra = {}) => ({ k, l, u, type: "number", ...extra });

export const SECTIONS = {
  exercise: {
    title: "Exercises", icon: "dumbbell", shared: true, titleLabel: "Exercise name",
    desc: "Curate the shared exercise library that every member can use.",
    fields: [
      { k: "category", l: "Category", type: "select", options: ["Strength", "Cardio", "Mobility", "HIIT", "Flexibility"] },
      { k: "difficulty", l: "Difficulty", type: "select", options: ["Beginner", "Intermediate", "Advanced"] },
      { k: "muscleGroup", l: "Muscle group" },
      { k: "instructions", l: "Instructions", type: "textarea", full: true }
    ],
    cols: ["category", "difficulty", "muscleGroup"]
  },
  workout: {
    title: "Workouts", icon: "workout", shared: true, titleLabel: "Workout name",
    desc: "Build shared workout plans or review the routines members have created.",
    fields: [
      num("duration", "Duration", "min"), num("sets", "Sets"), num("reps", "Reps"),
      { k: "exercises", l: "Exercises", type: "textarea", full: true, hint: "One exercise per line" }
    ],
    cols: ["duration", "sets", "reps", "exercises"]
  },
  weight: {
    title: "Weight records", icon: "gauge", titleLabel: "Label",
    desc: "Body-weight history logged by members.",
    fields: [num("weightKg", "Weight", "kg", { step: "0.1" }), { k: "note", l: "Notes", type: "textarea", full: true }],
    cols: ["weightKg", "note"]
  },
  measurement: {
    title: "Body measurements", icon: "ruler", titleLabel: "Label",
    desc: "Waist, chest, arm and hip measurements over time.",
    fields: [num("waistCm", "Waist", "cm", { step: "0.1" }), num("chestCm", "Chest", "cm", { step: "0.1" }), num("armCm", "Arm", "cm", { step: "0.1" }), num("hipsCm", "Hips", "cm", { step: "0.1" }), { k: "note", l: "Notes", type: "textarea", full: true }],
    cols: ["waistCm", "chestCm", "armCm", "hipsCm"]
  },
  performance: {
    title: "Performance", icon: "activity", titleLabel: "Session title",
    desc: "Strength, volume and personal-record tracking.",
    fields: [{ k: "exercise", l: "Exercise" }, num("sets", "Sets"), num("reps", "Reps"), num("weightKg", "Weight lifted", "kg", { step: "0.5" }), num("duration", "Duration", "min"), { k: "note", l: "Notes", type: "textarea", full: true }],
    cols: ["exercise", "sets", "reps", "weightKg", "duration"]
  },
  food: {
    title: "Nutrition", icon: "utensils", titleLabel: "Food item",
    desc: "Food diary entries with calories and macronutrients.",
    fields: [
      { k: "meal", l: "Meal", type: "select", options: ["Breakfast", "Lunch", "Dinner", "Snack"] }, { k: "serving", l: "Serving size" },
      num("calories", "Calories", "kcal"), num("protein", "Protein", "g", { step: "0.1" }), num("carbs", "Carbs", "g", { step: "0.1" }), num("fats", "Fats", "g", { step: "0.1" })
    ],
    cols: ["meal", "calories", "protein", "carbs", "fats"]
  },
  goal: {
    title: "Goals", icon: "target", titleLabel: "Goal title",
    desc: "Targets members have set, with their current progress.",
    fields: [
      { k: "goalType", l: "Goal type", type: "select", options: ["Weight loss", "Muscle gain", "Endurance", "Strength", "Flexibility", "Other"] },
      { k: "target", l: "Target" }, { k: "unit", l: "Unit" }, { k: "deadline", l: "Target date", type: "date" }, num("progress", "Progress", "%", { min: 0, max: 100 })
    ],
    cols: ["goalType", "target", "progress", "deadline"]
  }
};
