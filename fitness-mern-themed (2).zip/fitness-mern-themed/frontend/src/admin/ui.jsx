import { createContext, useCallback, useContext, useEffect, useState } from "react";

/* ------------------------------- Icons ------------------------------- */
const ICONS = {
  dashboard: <><rect x="3" y="3" width="7" height="9" rx="1.5" /><rect x="14" y="3" width="7" height="5" rx="1.5" /><rect x="14" y="12" width="7" height="9" rx="1.5" /><rect x="3" y="16" width="7" height="5" rx="1.5" /></>,
  users: <><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" /><circle cx="9" cy="7" r="4" /><path d="M22 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75" /></>,
  dumbbell: <path d="M6.5 6.5v11M17.5 6.5v11M3 9v6M21 9v6M6.5 12h11" />,
  workout: <><rect x="8" y="2" width="8" height="4" rx="1" /><path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2M9 12h6M9 16h6" /></>,
  gauge: <><circle cx="12" cy="12" r="9" /><path d="M12 12l4-4M7 17a7 7 0 0 1 10 0" /></>,
  ruler: <path d="M3 17L17 3l4 4L7 21zM7 13l2 2M10 10l2 2M13 7l2 2" />,
  activity: <path d="M22 12h-4l-3 9L9 3l-3 9H2" />,
  utensils: <path d="M4 3v7a2 2 0 0 0 2 2 2 2 0 0 0 2-2V3M6 3v18M18 21V3c-2 0-4 3-4 7 0 2 1 3 4 3" />,
  target: <><circle cx="12" cy="12" r="9" /><circle cx="12" cy="12" r="5" /><circle cx="12" cy="12" r="1" /></>,
  bell: <path d="M18 8a6 6 0 0 0-12 0c0 7-3 9-3 9h18s-3-2-3-9M13.7 21a2 2 0 0 1-3.4 0" />,
  lifebuoy: <><circle cx="12" cy="12" r="9" /><circle cx="12" cy="12" r="3.5" /><path d="M5.6 5.6l3.9 3.9M14.5 14.5l3.9 3.9M18.4 5.6l-3.9 3.9M9.5 14.5l-3.9 3.9" /></>,
  file: <path d="M14 3H6a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9zM14 3v6h6M8 13h8M8 17h5" />,
  settings: <><path d="M4 6h9M17 6h3M4 12h3M11 12h9M4 18h11M19 18h1" /><circle cx="15" cy="6" r="2" /><circle cx="9" cy="12" r="2" /><circle cx="17" cy="18" r="2" /></>,
  search: <path d="M11 4a7 7 0 1 0 0 14 7 7 0 0 0 0-14zM21 21l-4.3-4.3" />,
  plus: <path d="M12 5v14M5 12h14" />,
  edit: <path d="M12 20h9M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4z" />,
  trash: <path d="M3 6h18M8 6V4a1 1 0 0 1 1-1h6a1 1 0 0 1 1 1v2M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6" />,
  eye: <><path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12z" /><circle cx="12" cy="12" r="3" /></>,
  download: <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M7 10l5 5 5-5M12 15V3" />,
  sun: <><circle cx="12" cy="12" r="4" /><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4" /></>,
  moon: <path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z" />,
  menu: <path d="M3 6h18M3 12h18M3 18h18" />,
  x: <path d="M18 6L6 18M6 6l12 12" />,
  logout: <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4M16 17l5-5-5-5M21 12H9" />,
  check: <path d="M20 6L9 17l-5-5" />,
  alert: <path d="M10.3 3.9L1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0zM12 9v4M12 17h.01" />,
  send: <path d="M22 2L11 13M22 2l-7 20-4-9-9-4z" />,
  shield: <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />,
  trend: <path d="M23 6l-9.5 9.5-5-5L1 18M17 6h6v6" />,
  printer: <><path d="M6 9V2h12v7M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2" /><rect x="6" y="14" width="12" height="8" /></>,
  left: <path d="M15 18l-6-6 6-6" />,
  right: <path d="M9 18l6-6-6-6" />,
  ban: <><circle cx="12" cy="12" r="9" /><path d="M5.6 5.6l12.8 12.8" /></>,
  refresh: <path d="M21 12a9 9 0 1 1-3-6.7L21 8M21 3v5h-5" />,
  message: <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" />,
  inbox: <path d="M22 12h-6l-2 3h-4l-2-3H2M5.5 5h13l3.5 7v6a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2v-6z" />,
  key: <><circle cx="8" cy="15" r="4" /><path d="M10.8 12.2L21 2M16 7l3 3" /></>,
  filter: <path d="M22 3H2l8 9.5V19l4 2v-8.5z" />
};
export function Icon({ name, size = 18 }) {
  return <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">{ICONS[name] || null}</svg>;
}

/* ------------------------------ Small pieces ------------------------------ */
export function Avatar({ user, size = 36 }) {
  const initial = (user?.name || "?").trim().charAt(0).toUpperCase();
  return <span className="adm-avatar" style={{ width: size, height: size, fontSize: size * 0.4 }}>{user?.profileImage ? <img src={user.profileImage} alt="" /> : initial}</span>;
}
export function Badge({ tone = "muted", plain, children }) {
  return <span className={`adm-badge tone-${tone}${plain ? " plain" : ""}`}>{children}</span>;
}
export function Person({ user, size = 36, sub }) {
  return <div className="adm-person"><Avatar user={user} size={size} /><div><strong>{user?.name || "—"}</strong><small>{sub ?? user?.email}</small></div></div>;
}
export function PageHeader({ title, subtitle, children }) {
  return <div className="adm-head"><div><h1>{title}</h1>{subtitle && <p>{subtitle}</p>}</div>{children && <div className="adm-actions">{children}</div>}</div>;
}
export function Empty({ icon = "inbox", title, children }) {
  return <div className="adm-empty"><span className="ico"><Icon name={icon} size={24} /></span><strong>{title}</strong>{children && <span>{children}</span>}</div>;
}
export function Skeleton({ h = 16, w = "100%" }) { return <div className="adm-skel" style={{ height: h, width: w }} />; }
export function TableSkeleton({ rows = 6 }) {
  return <div style={{ padding: 16, display: "flex", flexDirection: "column", gap: 14 }}>{Array.from({ length: rows }, (_, i) => <Skeleton key={i} h={34} />)}</div>;
}
export function Alert({ tone = "bad", children }) {
  return <div className={`adm-alert tone-${tone}`}><Icon name={tone === "ok" ? "check" : "alert"} size={16} />{children}</div>;
}
export function Switch({ on, onChange, label }) {
  return <button type="button" role="switch" aria-checked={on} aria-label={label} className={`adm-switch${on ? " on" : ""}`} onClick={() => onChange(!on)} />;
}
export function Pager({ page, pages, total, size, onPage, label = "results" }) {
  if (!total) return null;
  const from = (page - 1) * size + 1, to = Math.min(page * size, total);
  return <div className="adm-pager"><span>Showing {from}–{to} of {total} {label}</span><div>
    <button className="adm-btn sm icon" disabled={page <= 1} onClick={() => onPage(page - 1)} aria-label="Previous page"><Icon name="left" size={15} /></button>
    <span>Page {page} / {pages}</span>
    <button className="adm-btn sm icon" disabled={page >= pages} onClick={() => onPage(page + 1)} aria-label="Next page"><Icon name="right" size={15} /></button></div></div>;
}

export function Modal({ open, title, onClose, children, footer, size }) {
  useEffect(() => {
    if (!open) return;
    const onKey = (e) => e.key === "Escape" && onClose();
    document.addEventListener("keydown", onKey);
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => { document.removeEventListener("keydown", onKey); document.body.style.overflow = prev; };
  }, [open, onClose]);
  if (!open) return null;
  return <div className="adm-overlay" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
    <div className={`adm-modal ${size || ""}`} role="dialog" aria-modal="true" aria-label={title}>
      <div className="adm-modal-h"><h2>{title}</h2><button className="adm-iconbtn" onClick={onClose} aria-label="Close"><Icon name="x" size={16} /></button></div>
      <div className="adm-modal-b">{children}</div>
      {footer && <div className="adm-modal-f">{footer}</div>}
    </div></div>;
}

/* --------------------------- Toasts + confirm --------------------------- */
const UIContext = createContext(null);
export function AdminUIProvider({ children }) {
  const [toasts, setToasts] = useState([]);
  const [dialog, setDialog] = useState(null);
  const toast = useCallback((message, tone = "ok") => {
    const id = Date.now() + Math.random();
    setToasts((t) => [...t, { id, message, tone }]);
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 3800);
  }, []);
  const confirm = useCallback((opts) => new Promise((resolve) => setDialog({ ...opts, resolve })), []);
  const answer = (value) => { dialog.resolve(value); setDialog(null); };
  return <UIContext.Provider value={{ toast, confirm }}>
    {children}
    <div className="adm-toasts" aria-live="polite">{toasts.map((t) => <div className="adm-toast" key={t.id}><span className={`ti tone-${t.tone}`}><Icon name={t.tone === "ok" ? "check" : "alert"} size={14} /></span>{t.message}</div>)}</div>
    <Modal open={!!dialog} size="sm" title={dialog?.title || "Are you sure?"} onClose={() => answer(false)}
      footer={<><button className="adm-btn" onClick={() => answer(false)}>Cancel</button><button className={`adm-btn ${dialog?.danger ? "danger solid" : "primary"}`} onClick={() => answer(true)}>{dialog?.confirmText || "Confirm"}</button></>}>
      <p style={{ color: "var(--muted)" }}>{dialog?.message}</p>
    </Modal>
  </UIContext.Provider>;
}
export const useAdminUI = () => useContext(UIContext);

export function useDebounce(value, delay = 300) {
  const [v, setV] = useState(value);
  useEffect(() => { const t = setTimeout(() => setV(value), delay); return () => clearTimeout(t); }, [value, delay]);
  return v;
}
