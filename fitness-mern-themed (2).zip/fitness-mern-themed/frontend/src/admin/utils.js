import api from "../api";

export const fmtDate = (d) => (d ? new Date(d).toLocaleDateString(undefined, { year: "numeric", month: "short", day: "numeric" }) : "—");
export const timeAgo = (d) => {
  if (!d) return "Never";
  const s = Math.max(1, Math.floor((Date.now() - new Date(d)) / 1000));
  const units = [["year", 31536000], ["month", 2592000], ["day", 86400], ["hour", 3600], ["minute", 60]];
  for (const [name, secs] of units) if (s >= secs) { const n = Math.floor(s / secs); return `${n} ${name}${n > 1 ? "s" : ""} ago`; }
  return "Just now";
};
export const errorText = (e, fallback = "Something went wrong.") => e?.response?.data?.message || (e?.message === "Network Error" ? "Cannot reach the server." : fallback);
export const GOALS = { muscle_gain: "Muscle gain", weight_loss: "Weight loss", maintenance: "Maintenance", general_fitness: "General fitness", "": "—" };

// Downloads a CSV report from the API (the token is sent in the Authorization header, so a plain link would not work).
export async function downloadReport(what, params = {}) {
  const res = await api.get(`/admin/export/${what}`, { params, responseType: "blob" });
  const name = /filename="([^"]+)"/.exec(res.headers["content-disposition"] || "")?.[1] || `fitzone-${what}.csv`;
  const url = URL.createObjectURL(res.data);
  const a = Object.assign(document.createElement("a"), { href: url, download: name });
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

const esc = (v) => String(v ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

// Opens a print-ready report. The window is opened synchronously (inside the click handler) to avoid popup blockers.
export async function printReport(what, params = {}) {
  const win = window.open("", "_blank");
  if (!win) throw new Error("Allow pop-ups for this site to create PDF reports.");
  win.document.write("<p style='font-family:sans-serif;padding:24px'>Preparing report…</p>");
  try {
    const { data } = await api.get(`/admin/export/${what}`, { params: { ...params, format: "json" } });
    const range = params.from || params.to ? ` · ${params.from || "start"} → ${params.to || "today"}` : "";
    win.document.open();
    win.document.write(`<!doctype html><html><head><meta charset="utf-8"><title>FitZone — ${esc(data.title)}</title><style>
      @page{size:A4 landscape;margin:14mm}body{font-family:system-ui,Arial,sans-serif;color:#111;margin:0}
      h1{font-size:20px;margin:0}p{color:#555;font-size:12px;margin:4px 0 16px}
      table{width:100%;border-collapse:collapse;font-size:11px}th{background:#f1f3f6;text-align:left}th,td{border:1px solid #d9dee5;padding:5px 7px}tr:nth-child(even) td{background:#fafbfc}
    </style></head><body><h1>FitZone — ${esc(data.title)} report</h1><p>Generated ${new Date().toLocaleString()}${esc(range)} · ${data.rows.length} rows</p>
    <table><thead><tr>${data.columns.map((c) => `<th>${esc(c)}</th>`).join("")}</tr></thead><tbody>${data.rows.map((r) => `<tr>${r.map((c) => `<td>${esc(c)}</td>`).join("")}</tr>`).join("") || `<tr><td colspan="${data.columns.length}">No data for this selection.</td></tr>`}</tbody></table>
    <script>window.onload=()=>setTimeout(()=>window.print(),250)</script></body></html>`);
    win.document.close();
  } catch (e) { win.close(); throw e; }
}
