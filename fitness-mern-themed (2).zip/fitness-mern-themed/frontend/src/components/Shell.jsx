import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../auth/AuthContext";

const KEY = "fitzone_theme";

function initialTheme() {
  try {
    const saved = localStorage.getItem(KEY);
    if (saved === "light" || saved === "dark") return saved;
  } catch {}
  return window.matchMedia?.("(prefers-color-scheme: light)").matches ? "light" : "dark";
}

function useTheme() {
  const [theme, setTheme] = useState(initialTheme);
  useEffect(() => {
    document.documentElement.setAttribute("data-theme", theme);
    document.querySelector('meta[name="theme-color"]')?.setAttribute("content", theme === "light" ? "#f4f6fa" : "#0a0f16");
    try { localStorage.setItem(KEY, theme); } catch {}
  }, [theme]);
  return [theme, () => setTheme((t) => (t === "dark" ? "light" : "dark"))];
}

export default function Shell({ children, dashboard = false }) {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [theme, toggleTheme] = useTheme();
  function signOut() { logout(); navigate("/"); }
  return (
    <div className="app-shell">
      <header className="topbar">
        <Link to="/" className="brand"><span className="brand-mark">F</span> FitZone</Link>
        <nav>
          <a href="/#programs">Programs</a><a href="/#about">About</a>
          <button type="button" className="theme-toggle" onClick={toggleTheme} title="Toggle light / dark theme" aria-label="Toggle light or dark theme">{theme === "dark" ? "☀" : "☾"}</button>
          {user ? <><Link to={user.role === "admin" ? "/admin/profile" : "/client/profile"} className="nav-user">{user.name}</Link><Link className="btn btn-outline btn-small" to={user.role === "admin" ? "/admin/dashboard" : "/client/dashboard"}>Dashboard</Link><button className="btn btn-outline btn-small" onClick={signOut}>Log out</button></> :
            <><Link to="/login">Log in</Link><Link className="btn btn-primary btn-small" to="/register">Join now</Link></>}
        </nav>
      </header>
      {children}
      {!dashboard && <footer>© {new Date().getFullYear()} FitZone Fitness. Train smart. Stay consistent.</footer>}
    </div>
  );
}
