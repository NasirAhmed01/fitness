import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import Shell from "../components/Shell";
import { useAuth } from "../auth/AuthContext";
import api from "../api";

export default function ClientDashboard() {
  const { user } = useAuth();
  const [dashboard, setDashboard] = useState(null);
  const [error, setError] = useState("");
  useEffect(() => { api.get("/client/dashboard").then(r=>setDashboard(r.data)).catch(e=>setError(e.response?.data?.message || "Unable to load dashboard.")); }, []);
  return <Shell dashboard><main className="dashboard-page"><div className="dashboard-top"><div><div className="eyebrow">CLIENT SPACE</div><h1>Welcome, {user?.name?.split(" ")[0]}.</h1><p>Every good workout begins with a plan.</p></div><div className="role-chip">● CLIENT ACCOUNT</div></div>
    {error && <div className="error-box">{error}</div>}<div className="welcome-panel"><div><span className="panel-kicker">YOUR FITNESS DASHBOARD</span><h2>Progress is built one session at a time.</h2><p>Choose a goal, stay consistent, and make recovery part of your routine.</p></div><div className="panel-emblem">FZ</div></div>
    <div className="dashboard-cards"><article><span className="dash-icon">↗</span><h3>Training plan</h3><p>Start with a realistic weekly routine and adjust it as you improve.</p><span className="card-status">READY TO PLAN</span></article><article><span className="dash-icon">◎</span><h3>Progress tracking</h3><p>Record your sessions, sets, reps, and personal bests consistently.</p><span className="card-status">BUILD YOUR HABIT</span></article><article><span className="dash-icon">＋</span><h3>Recovery</h3><p>Prioritize sleep, hydration, and rest between hard sessions.</p><span className="card-status">STAY BALANCED</span></article></div>
    <section className="tips-panel"><div className="eyebrow">FITNESS TRACKER</div><h2>Track your daily progress</h2><div className="tracker-nav">{[["exercise","Exercises"],["workout","Workouts"],["weight","Weight"],["measurement","Measurements"],["performance","Performance"],["food","Food diary"],["goal","Goals"],["notification","Notifications"],["support","Support"],["profile","Edit profile"]].map(([p,l])=><Link key={p} to={p==="profile"?"/client/profile":`/client/${p}`}>{l}</Link>)}</div></section><section className="tips-panel"><div className="eyebrow">YOUR NEXT STEPS</div><h2>Fitness fundamentals</h2>{(dashboard?.tips || ["Warm up before training.","Track your workouts.","Get enough sleep and hydration."]).map((tip,i)=><div className="tip-row" key={tip}><span>0{i+1}</span><p>{tip}</p><b>↗</b></div>)}</section>
  </main></Shell>;
}
