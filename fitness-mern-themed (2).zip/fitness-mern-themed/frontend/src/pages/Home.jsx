import { Link } from "react-router-dom";
import Shell from "../components/Shell";

export default function Home() {
  return <Shell>
    <main>
      <section className="hero">
        <div className="hero-copy">
          <div className="eyebrow"><span className="pulse"></span> YOUR NEXT LEVEL STARTS HERE</div>
          <h1>Build strength.<br /><span>Become unstoppable.</span></h1>
          <p>Training that fits your goals. A stronger body starts with one focused session at a time.</p>
          <div className="hero-actions"><Link to="/register" className="btn btn-primary">Start your journey <span>↗</span></Link><a href="#programs" className="btn btn-ghost">Explore programs</a></div>
          <div className="hero-proof"><div className="proof-avatars"><i>J</i><i>A</i><i>M</i></div><span><strong>Consistency over perfection.</strong><br />Your progress, your pace.</span></div>
        </div>
        <div className="hero-visual"><div className="hero-image"><div className="image-label">BUILT BY DISCIPLINE</div><div className="image-number">01 <span>/ TRAIN</span></div></div><div className="float-card"><span className="float-icon">↗</span><div><strong>Make it count.</strong><small>One rep at a time.</small></div></div></div>
      </section>
      <section className="stats-strip"><div><strong>01</strong><span>Set your goal</span></div><div><strong>02</strong><span>Build your routine</span></div><div><strong>03</strong><span>Track your progress</span></div><div><strong>04</strong><span>Keep showing up</span></div></section>
      <section className="programs section" id="programs"><div className="section-heading"><div><div className="eyebrow">TRAIN WITH PURPOSE</div><h2>Find your focus.</h2></div><p>Simple, structured training principles to help you get started.</p></div>
        <div className="program-grid"><article className="program-card card-strength"><span>01 / STRENGTH</span><h3>Build strength</h3><p>Compound lifts, sound technique, and gradual progression.</p></article><article className="program-card card-conditioning"><span>02 / CONDITIONING</span><h3>Improve endurance</h3><p>Build work capacity with a balanced conditioning routine.</p></article><article className="program-card card-recovery"><span>03 / RECOVERY</span><h3>Recover better</h3><p>Make sleep, mobility, and nutrition part of your plan.</p></article></div>
      </section>
      <section className="join-banner" id="about"><div><div className="eyebrow">START WHERE YOU ARE</div><h2>Your future self will thank you.</h2><p>Create your free account and take the first step.</p></div><Link className="btn btn-light" to="/register">Create account ↗</Link></section>
    </main>
  </Shell>;
}
