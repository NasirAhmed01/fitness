import { useState } from "react";
import { Link, Navigate, useLocation, useNavigate } from "react-router-dom";
import { useAuth } from "../auth/AuthContext";
import Shell from "../components/Shell";

export default function Login() {
  const { user, login } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [form, setForm] = useState({ email: "", password: "" });
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  if (user) return <Navigate to={user.role === "admin" ? "/admin/dashboard" : "/client/dashboard"} replace />;
  async function submit(e) {
    e.preventDefault(); setError(""); setBusy(true);
    try {
      const loggedIn = await login(form.email, form.password);
      const target = loggedIn.role === "admin" ? "/admin/dashboard" : "/client/dashboard";
      navigate(location.state?.from || target, { replace: true });
    } catch (err) { setError(err.response?.data?.message || "Could not connect to the server."); }
    finally { setBusy(false); }
  }
  return <Shell><main className="auth-wrap"><section className="auth-art"><div className="eyebrow">WELCOME BACK</div><h1>Show up.<br /><span>Get stronger.</span></h1><p>Your next session is another chance to move forward.</p><div className="auth-art-stamp">FITZONE<br /><span>TRAIN WITH INTENT</span></div></section>
    <section className="auth-panel"><div className="auth-heading"><div className="eyebrow">MEMBER ACCESS</div><h2>Log in to FitZone</h2><p>Enter your details to continue.</p></div>
      <form onSubmit={submit} className="auth-form"><label>Email address<input type="email" autoComplete="email" required value={form.email} onChange={e=>setForm({...form,email:e.target.value})} placeholder="you@example.com" /></label><label>Password<input type="password" autoComplete="current-password" required value={form.password} onChange={e=>setForm({...form,password:e.target.value})} placeholder="Your password" /></label>
      {error && <div className="error-box">{error}</div>}<button disabled={busy} className="btn btn-primary btn-full">{busy ? "Logging in…" : "Log in →"}</button></form>
      <p className="auth-switch">New to FitZone? <Link to="/register">Create an account</Link></p>
    </section></main></Shell>;
}
