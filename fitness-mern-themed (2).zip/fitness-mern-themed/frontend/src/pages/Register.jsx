import { useState } from "react";
import { Link, Navigate, useNavigate } from "react-router-dom";
import { useAuth } from "../auth/AuthContext";
import Shell from "../components/Shell";

export default function Register() {
  const { user, register } = useAuth();
  const navigate = useNavigate();
  const [form, setForm] = useState({ name: "", email: "", password: "", confirmPassword: "" });
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  if (user) return <Navigate to={user.role === "admin" ? "/admin/dashboard" : "/client/dashboard"} replace />;

  async function submit(e) {
    e.preventDefault(); 
    setError(""); 

    // Password match validation
    if (form.password !== form.confirmPassword) {
      setError("Passwords do not match.");
      return;
    }

    setBusy(true);
    try { 
      await register(form.name, form.email, form.password); 
      navigate("/client/dashboard", { replace: true }); 
    }
    catch (err) { 
      setError(err.response?.data?.message || "Could not connect to the server."); 
    }
    finally { 
      setBusy(false); 
    }
  }

  return (
    <Shell>
      <main className="auth-wrap">
        <section className="auth-art">
          <div className="eyebrow">YOUR JOURNEY, YOUR RULES</div>
          <h1>Small steps.<br /><span>Real progress.</span></h1>
          <p>Build a routine you can stick to. Your fitness journey starts here.</p>
          <div className="auth-art-stamp">FITZONE<br /><span>START TODAY</span></div>
        </section>
        
        <section className="auth-panel">
          <div className="auth-heading">
            <div className="eyebrow">JOIN THE COMMUNITY</div>
            <h2>Create your account</h2>
            <p>Sign up for your free client account.</p>
          </div>
          
          <form onSubmit={submit} className="auth-form">
            <label>
              Full name
              <input 
                autoComplete="name" 
                required 
                minLength="2" 
                value={form.name} 
                onChange={e => setForm({...form, name: e.target.value})} 
                placeholder="Your name" 
              />
            </label>

            <label>
              Email address
              <input 
                type="email" 
                autoComplete="email" 
                required 
                value={form.email} 
                onChange={e => setForm({...form, email: e.target.value})} 
                placeholder="you@example.com" 
              />
            </label>

            <label>
              Password
              <input 
                type="password" 
                autoComplete="new-password" 
                required 
                minLength="8" 
                value={form.password} 
                onChange={e => setForm({...form, password: e.target.value})} 
                placeholder="At least 8 characters" 
              />
            </label>

            <label>
              Confirm Password
              <input 
                type="password" 
                autoComplete="new-password" 
                required 
                minLength="8" 
                value={form.confirmPassword} 
                onChange={e => setForm({...form, confirmPassword: e.target.value})} 
                placeholder="Re-enter password" 
              />
            </label>

            {error && <div className="error-box">{error}</div>}
            
            <button disabled={busy} className="btn btn-primary btn-full">
              {busy ? "Creating account…" : "Create account →"}
            </button>
          </form>

          <p className="auth-switch">Already registered? <Link to="/login">Log in</Link></p>
          <p className="fine-print">Public sign-up creates client accounts only.</p>
        </section>
      </main>
    </Shell>
  );
}