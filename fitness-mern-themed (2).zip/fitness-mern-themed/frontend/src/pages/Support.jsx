import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import Shell from "../components/Shell";
import api from "../api";

const STATUS = { open: "Open", in_progress: "In progress", resolved: "Resolved" };

// Member-facing support & feedback page (the admin answers these in /admin/support).
export default function Support() {
  const [tickets, setTickets] = useState([]);
  const [form, setForm] = useState({ subject: "", message: "", category: "question", priority: "medium" });
  const [reply, setReply] = useState({});
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const load = () => api.get("/support/mine").then((r) => setTickets(r.data.tickets)).catch((e) => setError(e.response?.data?.message || "Unable to load tickets."));
  useEffect(() => { load(); }, []);

  async function submit(e) {
    e.preventDefault(); setError(""); setNotice("");
    try { await api.post("/support", form); setForm({ subject: "", message: "", category: "question", priority: "medium" }); setNotice("Your request was sent. We'll reply here."); load(); }
    catch (err) { setError(err.response?.data?.message || "Could not send your request."); }
  }
  async function send(id) {
    if (!reply[id]?.trim()) return;
    try { await api.post(`/support/${id}/reply`, { message: reply[id] }); setReply((r) => ({ ...r, [id]: "" })); load(); } catch (err) { setError(err.response?.data?.message || "Could not send reply."); }
  }

  return <Shell dashboard><main className="dashboard-page">
    <div className="dashboard-top"><div><div className="eyebrow">HELP & FEEDBACK</div><h1>Support.</h1><p>Contact the FitZone team, report an issue or share feedback.</p></div><Link className="btn btn-outline btn-small" to="/client/dashboard">← Dashboard</Link></div>
    {error && <div className="error-box">{error}</div>}{notice && <div className="success-box">{notice}</div>}
    <form className="tips-panel tracker-form" onSubmit={submit}><div className="eyebrow">NEW REQUEST</div>
      <div className="tracker-fields">
        <label>Subject<input required minLength="3" maxLength="140" value={form.subject} onChange={(e) => setForm({ ...form, subject: e.target.value })} /></label>
        <label>Type<select value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })}><option value="question">Question</option><option value="issue">Report an issue</option><option value="feedback">Feedback</option><option value="other">Other</option></select></label>
        <label>Priority<select value={form.priority} onChange={(e) => setForm({ ...form, priority: e.target.value })}><option value="low">Low</option><option value="medium">Medium</option><option value="high">High</option></select></label>
        <label style={{ gridColumn: "1/-1" }}>Message<textarea required minLength="10" maxLength="3000" rows="4" value={form.message} onChange={(e) => setForm({ ...form, message: e.target.value })} /></label>
      </div><div className="form-actions"><button className="btn btn-primary">Send request</button></div></form>
    <section className="tips-panel"><div className="eyebrow">YOUR REQUESTS · {tickets.length}</div>
      {tickets.length === 0 ? <p className="empty-state">No requests yet.</p> : <div className="record-grid">{tickets.map((t) => <article className="record-card" key={t._id}>
        <span className="card-status">{STATUS[t.status]}</span><h3>{t.subject}</h3><p style={{ whiteSpace: "pre-wrap" }}>{t.message}</p>
        {t.replies.map((r) => <p key={r._id} style={{ whiteSpace: "pre-wrap", borderLeft: `3px solid ${r.role === "admin" ? "var(--orange)" : "var(--line)"}`, paddingLeft: 10 }}><small>{r.role === "admin" ? "FitZone team" : "You"}</small><br />{r.message}</p>)}
        <div className="form-actions"><input placeholder="Add a reply…" value={reply[t._id] || ""} onChange={(e) => setReply({ ...reply, [t._id]: e.target.value })} /><button className="btn btn-outline btn-small" onClick={() => send(t._id)}>Reply</button></div></article>)}</div>}
    </section></main></Shell>;
}
